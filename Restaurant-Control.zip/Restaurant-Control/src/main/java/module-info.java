module org.example.restaurante {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens org.example.restaurante to javafx.fxml;

    exports org.example.restaurante;

    requires mysql.connector.j;
    requires itextpdf;
    requires layout;
    requires kernel;
    requires io;
    requires javafx.swing;
    requires javafx.graphics;
    requires java.desktop;

    opens org.example.restaurante.modelos;
    opens org.example.restaurante.modelosEntidad;
    opens org.example.restaurante.componentes;
}