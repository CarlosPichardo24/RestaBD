package org.example.restaurante.vistas.registro;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.example.restaurante.componentes.TxtRegistro;
import org.example.restaurante.modelos.Registro;
import org.example.restaurante.modelosEntidad.ClienteDAO;

public class RegistroCliente extends Stage implements Registro<ClienteDAO> {
    private Text title;
    private TxtRegistro txtNombre, txtDireccion, txtTelefono, txtEmail;
    private Button btnGuardar;
    private VBox vbox;
    private Scene scene;
    private ClienteDAO obj;
    private TableView<ClienteDAO> tbvCliente;

    public void crearUI(){
        title = new Text("Cliente");
        title.getStyleClass().add("title");

        txtNombre = new TxtRegistro("Nombre Cliente", "txtField");

        txtDireccion = new TxtRegistro("Direccion Cliente","txtField");

        txtTelefono = new TxtRegistro("Telefono Cliente","txtField");

        txtEmail = new TxtRegistro("Email Cliente","txtField");

        btnGuardar = new Button("Guardar");
        btnGuardar.getStyleClass().add("btnGuardar");
        btnGuardar.setOnAction(e -> {
            obj.setNombre(txtNombre.getText());
            obj.setDireccion(txtDireccion.getText());
            obj.setTelefono(txtTelefono.getText());
            obj.setEmail(txtEmail.getText());

            if(obj.getIdCliente() > 0)
                obj.UPDATE();

            else
                obj.INSERT();

            tbvCliente.setItems(obj.SELECT());
            tbvCliente.refresh();

            this.close();
        });

        vbox = new VBox(title, txtNombre, txtDireccion, txtTelefono, txtEmail, btnGuardar);
        vbox.getStyleClass().add("vboxBody");
        vbox.setPadding(new Insets(10, 15, 20, 15));
        vbox.setSpacing(10);
        vbox.setAlignment(Pos.TOP_CENTER);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/registroStyle.css").toString());
    }

    @Override
    public void llenar(ClienteDAO obj){
        this.obj = obj;

        txtNombre.setText(obj.getNombre());
        txtDireccion.setText(obj.getDireccion());
        txtTelefono.setText(obj.getTelefono());
        txtEmail.setText(obj.getEmail());

        this.show();
    }

    public RegistroCliente(TableView<ClienteDAO> tbvCliente, boolean show) {
        this.tbvCliente = tbvCliente;
        obj = new ClienteDAO();

        crearUI();

        this.setMinWidth(320);
        this.setTitle("Cliente");
        this.setScene(scene);
        if(show)
            this.show();
    }
}
