package org.example.restaurante.modelos;

public interface Registro<E> {
    void llenar(E obj);
}
