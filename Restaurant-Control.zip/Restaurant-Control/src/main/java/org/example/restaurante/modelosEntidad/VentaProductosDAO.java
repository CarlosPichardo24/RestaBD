package org.example.restaurante.modelosEntidad;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.restaurante.modelos.Conexion;

import java.sql.ResultSet;
import java.sql.Statement;

public class VentaProductosDAO {
    private String producto;
    private float totalVendido;

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public float getTotalVendido() {
        return totalVendido;
    }

    public void setTotalVendido(float totalVendido) {
        this.totalVendido = totalVendido;
    }

    public ObservableList<VentaProductosDAO>  SELECT()
    {
        String query = "SELECT * from ventaproductos";
        ObservableList<VentaProductosDAO> list = FXCollections.observableArrayList();
        VentaProductosDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new VentaProductosDAO();
                obj.setProducto(res.getString("producto"));
                obj.setTotalVendido(res.getFloat("total_vendido"));
                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    return list;
    }
}



