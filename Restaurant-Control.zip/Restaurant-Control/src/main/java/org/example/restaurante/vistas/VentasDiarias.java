package org.example.restaurante.vistas;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.restaurante.modelosEntidad.VentasDiariasDAO;

public class VentasDiarias extends Stage {

    private Scene scene;
    private VentasDiariasDAO obj;
    private ObservableList<VentasDiariasDAO> datosVentas;

    public void crearUI() {
        TabPane tabPane = new TabPane();

        Tab tabBarras = new Tab("Gráfica de Barras de Numero de Ventas");
        tabBarras.setContent(crearGraficaBarras(true));
        tabBarras.setClosable(false);
        tabBarras.setId("tabGraph");

        Tab tabLineas = new Tab("Gráfica de Líneas");
        tabLineas.setContent(crearGraficaLineas());
        tabLineas.setClosable(false);
        tabLineas.setId("tabGraph");

        tabPane.getTabs().addAll(tabBarras, tabLineas);
        tabPane.getStyleClass().add("tab-pane");

        scene = new Scene(tabPane);
        scene.getStylesheets().add(getClass().getResource("/styles/tableStyle.css").toString());
        scene.getStylesheets().add(getClass().getResource("/styles/labelStyle.css").toString());
        scene.getStylesheets().add(getClass().getResource("/styles/tabStyle.css").toString());
    }

    public VentasDiarias() {
        obj = new VentasDiariasDAO();
        datosVentas = obj.SELECT();
    }

    public ObservableList<VentasDiariasDAO> cargarDatosVentas() {
        datosVentas.clear();
        VentasDiariasDAO ventaDAO = new VentasDiariasDAO();
        ObservableList<VentasDiariasDAO> datos = ventaDAO.SELECT();
        datosVentas.addAll(datos);
        return datosVentas;
    }
    public BarChart<String, Number> crearGraficaBarras(boolean mostrarVentas) {
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Días");
        yAxis.setLabel(mostrarVentas ? "Ventas Totales ($)" : "Número de Órdenes");

        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle(mostrarVentas ? "Ventas por Día" : "Órdenes por Día");
        barChart.getStylesheets().add(getClass().getResource("/styles/graficaStyle.css").toString());

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName(mostrarVentas ? "Ventas Totales" : "Órdenes");

        for (VentasDiariasDAO venta : datosVentas) {
            Number value = mostrarVentas ? venta.getTotal_ventas() : venta.getTotal_ordenes();
            series.getData().add(new XYChart.Data<>(venta.getDia().toString(), value));
        }

        barChart.getData().add(series);
        return barChart;
    }

    public Node getContent() {
        VBox content = new VBox();
        TabPane tabPane = new TabPane();

        Tab tabVentas = new Tab("Ventas Totales");
        tabVentas.setContent(crearGraficaBarras(true));
        tabVentas.setClosable(false);

        Tab tabOrdenes = new Tab("Número de Órdenes");
        tabOrdenes.setContent(crearGraficaBarras(false));
        tabOrdenes.setClosable(false);

        Tab tabLineas = new Tab("Tendencia");
        tabLineas.setContent(crearGraficaLineas());
        tabLineas.setClosable(false);

        tabPane.getTabs().addAll(tabVentas, tabOrdenes, tabLineas);
        content.getChildren().add(tabPane);
        return content;
    }

    public LineChart<String, Number> crearGraficaLineas() {
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Días");
        yAxis.setLabel("Ventas Totales");

        LineChart<String, Number> lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setTitle("Tendencia de Ventas Diarias");

        XYChart.Series<String, Number> seriesVentas = new XYChart.Series<>();
        seriesVentas.setName("Ventas Totales");

        XYChart.Series<String, Number> seriesOrdenes = new XYChart.Series<>();
        seriesOrdenes.setName("Número de Órdenes");

        for (VentasDiariasDAO venta : datosVentas) {
            seriesVentas.getData().add(new XYChart.Data<>(venta.getDia().toString(), venta.getTotal_ventas()));
            seriesOrdenes.getData().add(new XYChart.Data<>(venta.getDia().toString(), venta.getTotal_ordenes()));
        }

        lineChart.getData().addAll(seriesVentas, seriesOrdenes);
        lineChart.setCreateSymbols(true);
        return lineChart;
    }


    public void actualizarDatos() {
        datosVentas.clear();
        datosVentas.addAll(obj.SELECT());
    }

    public ObservableList<VentasDiariasDAO> getDatosVentas() {
        return datosVentas;
    }
}