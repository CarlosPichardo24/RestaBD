package org.example.restaurante.modelosEntidad;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.restaurante.modelos.Conexion;

import java.sql.ResultSet;
import java.sql.Statement;

public class DetalleOrdenDAO {
    private int idProducto;
    private int idOrden;
    private int cantidad;

    public void INSERT(){
        String query = "INSERT INTO detalleOrden (idProducto, idOrden, cantidad) " +
                "VALUES ("+idProducto+", "+idOrden+", "+cantidad+")";
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void UPDATE(){
        String query = "UPDATE detalleOrden SET " +
                "idProducto = "+idProducto+", " +
                "idOrden = "+idOrden+", " +
                "cantidad = "+cantidad+" " +
                "WHERE idProducto = "+idProducto+" AND idOrden = "+idOrden;

        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void DELETE(){
        String query = "DELETE FROM detalleOrden WHERE idProducto = "+idProducto+" AND idOrden = "+idOrden;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ObservableList<DetalleOrdenDAO> SELECT(){
        String query = "SELECT * FROM detalleOrden";
        ObservableList<DetalleOrdenDAO> list = FXCollections.observableArrayList();
        DetalleOrdenDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new DetalleOrdenDAO();

                obj.setIdProducto(res.getInt("idProducto"));
                obj.setIdOrden(res.getInt("idOrden"));
                obj.setCantidad(res.getInt("cantidad"));

                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public ObservableList<DetalleOrdenDAO> selectOrden(int idOrden){
        String query = "SELECT * FROM detalleOrden WHERE idOrden = "+idOrden;
        ObservableList<DetalleOrdenDAO> list = FXCollections.observableArrayList();
        DetalleOrdenDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new DetalleOrdenDAO();

                obj.setIdProducto(res.getInt("idProducto"));
                obj.setIdOrden(res.getInt("idOrden"));
                obj.setCantidad(res.getInt("cantidad"));

                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public ProductoDAO getProducto() {
        ProductoDAO obj = null;
        String query = "SELECT * FROM producto WHERE idProducto = " + idProducto;
        try {
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            if (res.next()) {
                obj = new ProductoDAO();
                obj.setIdProducto(res.getInt("idProducto"));
                obj.setNombre(res.getString("nombre"));
                obj.setPrecio(res.getDouble("precio"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return obj;
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
