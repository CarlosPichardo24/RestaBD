package org.example.restaurante.modelosEntidad;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.restaurante.modelos.Conexion;
import org.example.restaurante.modelos.Entidad;
import org.example.restaurante.modelos.Nombrable;

import java.sql.ResultSet;
import java.sql.Statement;

public class ProductoDAO implements Entidad<ProductoDAO>, Nombrable {
    private int idProducto;
    private String nombre;
    private double precio;
    private int idCategoria;

    private String nomCategoria;

    public void INSERT(){
        String query = "INSERT INTO producto (nombre, precio, idCategoria) " +
                "VALUES ('"+nombre+"', "+precio+", "+idCategoria+")";
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void UPDATE(){
        String query = "UPDATE producto SET " +
                "nombre = '"+nombre+"', " +
                "precio = "+precio+", " +
                "idCategoria = "+idCategoria+" " +
                "WHERE idProducto = "+idProducto;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void DELETE(){
        String query = "DELETE FROM producto WHERE idProducto = "+idProducto;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ObservableList<ProductoDAO> SELECT(){
        String query = "SELECT * FROM producto";
        ObservableList<ProductoDAO> list = FXCollections.observableArrayList();
        ProductoDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new ProductoDAO();

                obj.setIdProducto(res.getInt("idProducto"));
                obj.setNombre(res.getString("nombre"));
                obj.setPrecio(res.getDouble("precio"));
                obj.setIdCategoria(res.getInt("idCategoria"));

                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
        setNomCategoria();
    }

    public String getNomCategoria() {
        return nomCategoria;
    }

    public void setNomCategoria() {
        String query = "SELECT * FROM categoria WHERE idCategoria = "+idCategoria;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            if (res.next()) {
                nomCategoria = res.getString("nombre");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
