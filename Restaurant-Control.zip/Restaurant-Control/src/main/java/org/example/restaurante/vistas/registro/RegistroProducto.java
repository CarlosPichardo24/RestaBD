package org.example.restaurante.vistas.registro;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.example.restaurante.componentes.TxtRegistro;
import org.example.restaurante.modelos.Registro;
import org.example.restaurante.modelosEntidad.CategoriaDAO;
import org.example.restaurante.modelosEntidad.ProductoDAO;

public class RegistroProducto extends Stage implements Registro<ProductoDAO> {
    private Text title;
    private ComboBox<CategoriaDAO> cmbCategoria;
    private TxtRegistro txtNombre, txtPrecio;
    private Button btnGuardar;
    private VBox vbox;
    private Scene scene;
    private ProductoDAO obj;
    private TableView<ProductoDAO> tbvProducto;

    public void crearUI(){
        title = new Text("Insumo");
        title.getStyleClass().add("title");

        CategoriaDAO objCategoria = new CategoriaDAO();
        cmbCategoria = new ComboBox<>();
        cmbCategoria.setItems(objCategoria.SELECT());

        txtNombre = new TxtRegistro("Nombre Producto", "txtField");

        txtPrecio = new TxtRegistro("Precio Producto", "txtField");

        btnGuardar = new Button("Guardar");
        btnGuardar.getStyleClass().add("btnGuardar");
        btnGuardar.setOnAction(e -> {
            obj.setNombre(txtNombre.getText());
            obj.setPrecio(Double.parseDouble(txtPrecio.getText()));
            obj.setIdCategoria(cmbCategoria.getValue().getIdCategoria());

            if(obj.getIdProducto() > 0)
                obj.UPDATE();
            else
                obj.INSERT();

            tbvProducto.setItems(obj.SELECT());
            tbvProducto.refresh();

            this.close();
        });

        vbox = new VBox(title, txtNombre, txtPrecio, cmbCategoria, btnGuardar);
        vbox.getStyleClass().add("vboxBody");
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(10, 10, 20, 10));
        vbox.setAlignment(Pos.TOP_CENTER);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/registroStyle.css").toString());

    }

    public void llenar(ProductoDAO obj){
        this.obj = obj;

        CategoriaDAO categoria = new CategoriaDAO();


        for (CategoriaDAO c : categoria.SELECT()) {
            if (c.getIdCategoria() == obj.getIdCategoria()) {
                categoria = c;
                break;
            }
        }

        txtNombre.setText(obj.getNombre());
        txtPrecio.setText(Double.toString(obj.getPrecio()));
        cmbCategoria.setValue(categoria);

        this.show();
    }

    public RegistroProducto(TableView<ProductoDAO> tbvProducto, boolean show){
        this.tbvProducto = tbvProducto;
        obj = new ProductoDAO();

        crearUI();

        this.setMinWidth(320);
        this.setTitle("Registro Insumo");
        this.setScene(scene);

        if(show)
            this.show();
    }
}
