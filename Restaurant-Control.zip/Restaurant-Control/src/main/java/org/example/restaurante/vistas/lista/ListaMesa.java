package org.example.restaurante.vistas.lista;

import javafx.scene.Scene;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.restaurante.componentes.BotonAgregar;
import org.example.restaurante.componentes.TablaEntidad;
import org.example.restaurante.modelosEntidad.MesaDAO;
import org.example.restaurante.vistas.registro.RegistroMesa;

public class ListaMesa extends Stage {
    private TablaEntidad<MesaDAO, RegistroMesa> tbeMesa;
    private MesaDAO objMesa;
    private RegistroMesa rgMesa;
    private VBox vbox;
    private ToolBar tlbMenu;
    private BotonAgregar btnAgregar;
    private Scene scene;

    public void crearUI(){
        tbeMesa = new TablaEntidad<>();
        objMesa = new MesaDAO();

        tbeMesa.setColumna("Nombre", "nombre");
        tbeMesa.setColumna("Capacidad", "capacidad");

        rgMesa = new RegistroMesa(tbeMesa, false);

        tbeMesa.crearTabla(objMesa, rgMesa);

        btnAgregar = new BotonAgregar();
        btnAgregar.setOnAction(e -> new RegistroMesa(tbeMesa, true));

        tlbMenu = new ToolBar(btnAgregar);

        vbox = new VBox(tlbMenu, tbeMesa);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/tableStyle.css").toString());
    }

    public ListaMesa() {
        crearUI();
        this.setTitle("Lista de Mesas");
        this.setMaximized(true);
        this.setScene(scene);
        this.show();
    }
}
