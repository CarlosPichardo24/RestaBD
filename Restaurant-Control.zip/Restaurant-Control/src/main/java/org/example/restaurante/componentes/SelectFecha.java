package org.example.restaurante.componentes;

import javafx.geometry.Insets;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

public class SelectFecha extends VBox {

    private HBox hbox;
    private Text title;
    private ComboBox<String> cmbDia, cmbMes;
    private TextField txtAño;

    public SelectFecha(String strTitle){

        title = new Text(strTitle);
        title.setStyle("-fx-font-size: 15px;");

        cmbDia = new ComboBox<>();
        cmbDia.getItems().addAll("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31");
        cmbDia.setVisibleRowCount(5);
        cmbDia.setPromptText("Dia");

        cmbMes = new ComboBox<>();
        cmbMes.getItems().addAll("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre");
        cmbMes.setVisibleRowCount(5);
        cmbMes.setPromptText("Mes");

        txtAño = new TextField();
        txtAño.setPromptText("Año");
        txtAño.setPrefWidth(80);

        hbox = new HBox(cmbDia, cmbMes, txtAño);
        hbox.setSpacing(10);

        this.getChildren().addAll(title, hbox);
        this.setSpacing(5);
        this.setPadding(new Insets(2));
    }

    public String getDia(){
        return cmbDia.getValue();
    }

    public String getMes() {
        return cmbMes.getValue();
    }

    public int numMes(){
        String mes = cmbMes.getValue();

        int mesNumero = switch (mes) {
            case "Enero" -> 1;
            case "Febrero" -> 2;
            case "Marzo" -> 3;
            case "Abril" -> 4;
            case "Mayo" -> 5;
            case "Junio" -> 6;
            case "Julio" -> 7;
            case "Agosto" -> 8;
            case "Septiembre" -> 9;
            case "Octubre" -> 10;
            case "Noviembre" -> 11;
            case "Diciembre" -> 12;
            default -> 0;
        };

        return mesNumero;
    }

    public String getAño(){
        return txtAño.getText();
    }

    public String getFecha(){
        return txtAño.getText() + "-" + String.format("%02d", numMes()) + "-" + String.format("%02d", Integer.parseInt(cmbDia.getValue()));
    }

    public void setAño(String año){
        txtAño.setText(año);
    }

    public void setMes(String mes){
        int numMes = Integer.parseInt(mes);
        switch (numMes) {
            case 1 -> cmbMes.setValue("Enero");
            case 2 -> cmbMes.setValue("Febrero");
            case 3 -> cmbMes.setValue("Marzo");
            case 4 -> cmbMes.setValue("Abril");
            case 5 -> cmbMes.setValue("Mayo");
            case 6 -> cmbMes.setValue("Junio");
            case 7 -> cmbMes.setValue("Julio");
            case 8 -> cmbMes.setValue("Agosto");
            case 9 -> cmbMes.setValue("Septiembre");
            case 10 -> cmbMes.setValue("Octubre");
            case 11 -> cmbMes.setValue("Noviembre");
            case 12 -> cmbMes.setValue("Diciembre");
        }
    }

    public void setDia(String dia){
        int numDia = Integer.parseInt(dia);
        cmbDia.setValue(Integer.toString(numDia));
    }

    public void setFechaCompleta(String fecha) {
        if (fecha == null || !fecha.contains("-")) return;

        try {
            String[] partes = fecha.split("-");
            if (partes.length == 3) {
                setAño(partes[0]);
                setMes(partes[1]);
                setDia(partes[2]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
