package org.example.restaurante.vistas;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import org.example.restaurante.componentes.BotonAgregar;
import org.example.restaurante.componentes.TablaEntidad;
import org.example.restaurante.modelos.Conexion;
import org.example.restaurante.modelosEntidad.CategoriaDAO;
import org.example.restaurante.modelosEntidad.VentaProductosDAO;

import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Statement;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.restaurante.modelosEntidad.VentaProductosDAO;
import org.example.restaurante.modelos.Conexion;

import org.example.restaurante.vistas.registro.RegistroCategoria;


public class TopProductosVendidos extends Stage {

    private Scene scene;
    private VentaProductosDAO obj;
    private ObservableList<VentaProductosDAO> datosVentas;

    public void crearUI() {

        TabPane tabPane = new TabPane();

        Tab tabBarras = new Tab("Gráfica de Barras");
        tabBarras.setContent(crearGraficaBarras());
        tabBarras.setClosable(false);
        tabBarras.setId("tabGraph");

        Tab tabPastel = new Tab("Gráfica de Pastel");
        tabPastel.setContent(crearGraficaPastel());
        tabPastel.setClosable(false);
        tabPastel.setId("tabGraph");

        Tab tabLineas = new Tab("Gráfica de Líneas");
        tabLineas.setContent(crearGraficaLineas());
        tabLineas.setClosable(false);
        tabLineas.setId("tabGraph");

        tabPane.getTabs().addAll(tabBarras, tabPastel, tabLineas);
        tabPane.getStyleClass().add("tab-pane");

        scene = new Scene(tabPane);

        scene.getStylesheets().add(getClass().getResource("/styles/tableStyle.css").toString());
        scene.getStylesheets().add(getClass().getResource("/styles/labelStyle.css").toString());
        scene.getStylesheets().add(getClass().getResource("/styles/tabStyle.css").toString());

    }

    public Node getContent() {
        VBox content = new VBox();

        TabPane tabPane = new TabPane();

        Tab tabBarras = new Tab("Gráfica de Barras");
        tabBarras.setContent(crearGraficaBarras());
        tabBarras.setClosable(false);

        Tab tabPastel = new Tab("Gráfica de Pastel");
        tabPastel.setContent(crearGraficaPastel());
        tabPastel.setClosable(false);

        Tab tabLineas = new Tab("Gráfica de Líneas");
        tabLineas.setContent(crearGraficaLineas());
        tabLineas.setClosable(false);

        tabPane.getTabs().addAll(tabBarras, tabPastel, tabLineas);
        content.getChildren().add(tabPane);

        return content;
    }

    public TopProductosVendidos() {
        obj = new VentaProductosDAO();
        datosVentas = obj.SELECT();
        }

    public ObservableList<VentaProductosDAO> cargarDatosVentas() {

        datosVentas.clear();

        VentaProductosDAO ventaDAO = new VentaProductosDAO();
        ObservableList<VentaProductosDAO> datos = ventaDAO.SELECT();
        datosVentas.addAll(datos);


        datosVentas.sort((v1, v2) -> Double.compare(v2.getTotalVendido(), v1.getTotalVendido()));
        return datosVentas;
    }

        public BarChart<String, Number> crearGraficaBarras () {
            CategoryAxis xAxis = new CategoryAxis();
            NumberAxis yAxis = new NumberAxis();
            xAxis.setLabel("Productos");
            yAxis.setLabel("Cantidad Vendida");

            BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
            barChart.setTitle("Productos Más Vendidos");

            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Ventas");

            for (VentaProductosDAO venta : datosVentas) {
                    series.getData().add(new XYChart.Data<>(venta.getProducto(), venta.getTotalVendido()));
            }

            barChart.getData().add(series);
            barChart.setLegendVisible(false);


            return barChart;
        }

        /**
         * Crea una gráfica de pastel con los productos más vendidos
         */
        public PieChart crearGraficaPastel () {
            ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();

            for (VentaProductosDAO venta : datosVentas) {
                pieChartData.add(new PieChart.Data(venta.getProducto(), venta.getTotalVendido()));
            }

            PieChart pieChart = new PieChart(pieChartData);
            pieChart.setTitle("Distribución de Ventas por Producto");
            return pieChart;
        }


        public LineChart<String, Number> crearGraficaLineas () {
            CategoryAxis xAxis = new CategoryAxis();
            NumberAxis yAxis = new NumberAxis();
            xAxis.setLabel("Productos");
            yAxis.setLabel("Cantidad Vendida");

            LineChart<String, Number> lineChart = new LineChart<>(xAxis, yAxis);
            lineChart.setTitle("Tendencia de Ventas por Producto");

            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Ventas");

            for (VentaProductosDAO venta : datosVentas) {

                    series.getData().add(new XYChart.Data<>(venta.getProducto(), venta.getTotalVendido()));
            }

            lineChart.getData().add(series);
            lineChart.setCreateSymbols(true);
            return lineChart;
        }
        public ObservableList<VentaProductosDAO> getTopProductos (int limite){
            ObservableList<VentaProductosDAO> topProductos = obj.SELECT();

            int count = 0;
            for (VentaProductosDAO venta : datosVentas) {
                if (count < limite || venta != null) {
                    topProductos.add(venta);
                    count++;
                } else {
                    break;
                }
            }

            return topProductos;
        }

        /**
         * Crea una gráfica de barras con solo los top N productos
         */

        public void actualizarDatos () {
            datosVentas.clear();
        }

        public ObservableList<VentaProductosDAO> getDatosVentas () {
            return datosVentas;
        }

   }