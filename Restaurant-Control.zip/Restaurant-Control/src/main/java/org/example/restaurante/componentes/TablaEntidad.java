package org.example.restaurante.componentes;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import org.example.restaurante.modelos.Entidad;
import org.example.restaurante.modelos.Registro;
import org.example.restaurante.modelosEntidad.ClienteDAO;

import java.util.ArrayList;
import java.util.Optional;

public class TablaEntidad<T extends Entidad<T>, R extends Registro<T>> extends TableView<T> {

    private ArrayList<TableColumn<T, ?>> lstColumnas;
    private T obj;
    private R objR;

    public TablaEntidad() {
        lstColumnas = new ArrayList<>();
    }

    public <V> void setColumna(String nomColumna, String nomAtributo) {
        TableColumn<T, V> columna = new TableColumn<>(nomColumna);
        columna.setCellValueFactory(new PropertyValueFactory<>(nomAtributo));

        columna.setCellFactory(new Callback<TableColumn<T, V>, TableCell<T, V>>() {
            @Override
            public TableCell<T, V> call(TableColumn<T, V> param) {
                return new TableCell<T, V>() {
                    @Override
                    protected void updateItem(V item, boolean empty) {
                        super.updateItem(item, empty);
                        if (!empty && item != null) {
                            setText(item.toString());
                            setAlignment(Pos.CENTER);  // Centra el texto
                        } else {
                            setText(null);
                        }
                    }
                };
            }
        });

        lstColumnas.add(columna);
    }

    public void crearTabla(T obj, R objR){
        for(int i = 0; i<lstColumnas.size(); i++){
            this.getColumns().add(lstColumnas.get(i));
        }

        this.obj = obj;
        this.objR = objR;

        TableColumn<T, Void> tbcEditar = new TableColumn<>("Editar");
        tbcEditar.setMaxWidth(100);
        tbcEditar.setCellFactory(new Callback<TableColumn<T, Void>, TableCell<T, Void>>() {
            @Override
            public TableCell<T, Void> call(TableColumn<T, Void> parametro) {
                return new TableCell<T, Void>() {
                    private Button btnEditar = new Button("Editar");

                    {
                        btnEditar.setOnAction(event -> {
                            T objSelect = this.getTableView().getItems().get(this.getIndex());
                            objR.llenar(objSelect);
                        });

                        btnEditar.getStyleClass().add("btnEditar");
                    }

                    @Override
                    protected void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (!empty) {
                            this.setGraphic(btnEditar);
                            setAlignment(Pos.CENTER);
                            setPadding(new Insets(5, 0, 5, 0));
                        }
                    }
                };

            }
        });

        TableColumn<T, Void> tbcEliminar = new TableColumn<>("Eliminar");
        tbcEliminar.setMaxWidth(100);
        tbcEliminar.setCellFactory( new Callback<TableColumn<T, Void>, TableCell<T, Void>>() {
            public TableCell<T, Void> call(TableColumn<T, Void> param) {
                return new TableCell<T, Void>() {
                    private Button btnEliminar = new Button("Eliminar");

                    {
                        btnEliminar.setOnAction(event -> {
                            T objSelect = this.getTableView().getItems().get(this.getIndex());
                            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                            alert.setContentText("¿Estas seguro de querer eliminar el registro?");
                            Optional<ButtonType> result = alert.showAndWait();
                            if(result.get() == ButtonType.OK){
                                objSelect.DELETE();
                                this.getTableView().getItems().remove(objSelect);
                                this.getTableView().refresh();
                            }
                        });

                        btnEliminar.getStyleClass().add("btnEliminar");
                    }
                    @Override
                    protected void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (!empty) {
                            this.setGraphic(btnEliminar);
                            setAlignment(Pos.CENTER);
                            setPadding(new Insets(5, 0, 5, 0));
                        }
                    }
                };
            }
        });

        this.getColumns().addAll(tbcEditar, tbcEliminar);
        this.getItems().setAll(obj.SELECT());
        this.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }
}
