package org.example.restaurante.modelosEntidad;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.restaurante.modelos.Conexion;
import org.example.restaurante.modelos.Entidad;

import java.sql.ResultSet;
import java.sql.Statement;

public class InsumoDAO implements Entidad<InsumoDAO> {
    private int idInsumo;
    private int idProveedor;
    private String nombre;
    private double costo;
    private String nomProveedor;

    public void INSERT(){
        String query = "INSERT INTO insumo (idProveedor, nombre, costo) " +
                "VALUES ("+idProveedor+", '"+nombre+"', "+costo+")";
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void UPDATE(){
        String query = "UPDATE insumo SET " +
                "idProveedor = "+idProveedor+", " +
                "nombre = '"+nombre+"', " +
                "costo = "+costo+" " +
                "WHERE idInsumo = "+idInsumo;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void DELETE(){
        String query = "DELETE FROM insumo WHERE idInsumo = "+idInsumo;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public ObservableList<InsumoDAO> SELECT(){
        String query = "SELECT * FROM insumo";
        ObservableList<InsumoDAO> list = FXCollections.observableArrayList();
        InsumoDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new InsumoDAO();

                obj.setIdInsumo(res.getInt("idInsumo"));
                obj.setIdProveedor(res.getInt("idProveedor"));
                obj.setNombre(res.getString("nombre"));
                obj.setCosto(res.getDouble("costo"));

                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public int getIdInsumo() {
        return idInsumo;
    }

    public void setIdInsumo(int idInsumo) {
        this.idInsumo = idInsumo;
    }
    public int getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
        setNomProveedor();
    }

    public String getNomProveedor() {
        return nomProveedor;
    }

    public void setNomProveedor() {
        String query = "SELECT * FROM proveedor WHERE idProveedor = "+idProveedor;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            if (res.next()) {
                nomProveedor = res.getString("nombre");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }
}
