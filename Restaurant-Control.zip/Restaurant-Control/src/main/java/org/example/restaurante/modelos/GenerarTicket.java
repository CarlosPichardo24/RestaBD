package org.example.restaurante.modelos;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import org.example.restaurante.modelosEntidad.CuentaDAO;
import org.example.restaurante.modelosEntidad.DetalleOrdenDAO;
import org.example.restaurante.modelosEntidad.ProductoDAO;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class GenerarTicket{


    public GenerarTicket(CuentaDAO a)
    {
        generarTicket(a);
    }

    public  void generarTicket(CuentaDAO cuenta) {
        try {

            File carpeta = new File("tickets");
            if (!carpeta.exists()) carpeta.mkdirs();


            String fechaHoraActual = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String nombreArchivo = "ticket_" + cuenta.getIdCuenta() + "_" + fechaHoraActual + ".pdf";
            String rutaSalida = "tickets/" + nombreArchivo;


            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(rutaSalida));
            document.open();


            Image logo = Image.getInstance(GenerarTicket.class.getResource("/iconos/iconoRestaurantG.png"));
            logo.scaleAbsolute(100, 100);
            logo.setAlignment(Image.ALIGN_CENTER);
            document.add(logo);


            Font tituloFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
            Paragraph titulo = new Paragraph("Ticket de Consumo", tituloFont);
            titulo.setAlignment(Element.ALIGN_CENTER);
            titulo.setSpacingAfter(10);
            document.add(titulo);


            Paragraph infoCuenta = new Paragraph(
                    "Cuenta #" + cuenta.getIdCuenta() +
                            "\nFecha: " + cuenta.getOrden().getFecha() +
                            "\nMesa: " + cuenta.getOrden().getMesa().getNombre() +
                            "\nMétodo de pago: " + cuenta.getMetodoPago(),
                    new Font(Font.FontFamily.HELVETICA, 12)
            );
            infoCuenta.setSpacingAfter(10);
            document.add(infoCuenta);


            PdfPTable tabla = new PdfPTable(3);
            tabla.setWidthPercentage(100);
            tabla.setWidths(new float[]{4, 1, 2});

            Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
            tabla.addCell(new PdfPCell(new Phrase("Producto", headerFont)));
            tabla.addCell(new PdfPCell(new Phrase("Cant.", headerFont)));
            tabla.addCell(new PdfPCell(new Phrase("Subtotal", headerFont)));

            List<DetalleOrdenDAO> detalles = new DetalleOrdenDAO().selectOrden(cuenta.getIdOrden());
            double totalCalculado = 0;

            for (DetalleOrdenDAO detalle : detalles) {
                ProductoDAO producto = detalle.getProducto();
                double subtotal = producto.getPrecio() * detalle.getCantidad();
                totalCalculado += subtotal;

                tabla.addCell(producto.getNombre());
                tabla.addCell(String.valueOf(detalle.getCantidad()));
                tabla.addCell(String.format("$%.2f", subtotal));
            }

            document.add(tabla);


            Paragraph total = new Paragraph("\nTotal: $" + String.format("%.2f", totalCalculado), headerFont);
            total.setAlignment(Element.ALIGN_RIGHT);
            document.add(total);


            Paragraph gracias = new Paragraph("\n¡Gracias por su visita!", new Font(Font.FontFamily.HELVETICA, 12, Font.ITALIC));
            gracias.setAlignment(Element.ALIGN_CENTER);
            document.add(gracias);

            document.close();

            File archivo = new File(rutaSalida);
            if (archivo.exists()) {
                Desktop.getDesktop().open(archivo);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
