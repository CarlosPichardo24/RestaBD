package org.example.restaurante.modelosEntidad;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.restaurante.modelos.Conexion;

import java.sql.ResultSet;
import java.sql.Statement;

public class CuentaDAO{
    private int idCuenta;
    private int idOrden;
    private String metodoPago;
    private double total;
    private boolean cerrada;
    private String nomMesa;

    public void INSERT() {
        String query = "INSERT INTO Cuenta (idOrden, metodoPago, total, cerrada) " +
                "VALUES (" + idOrden + ", '" + metodoPago + "', " + total + ", " + cerrada + ")";
        try {
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void UPDATE() {
        String query = "UPDATE Cuenta SET " +
                "idOrden = " + idOrden + ", " +
                "metodoPago = '" + metodoPago + "', " +
                "total = " + total + ", " +
                "cerrada = " + cerrada + " " +
                "WHERE idCuenta = " + idCuenta;
        try {
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void DELETE() {
        String query = "DELETE FROM Cuenta WHERE idCuenta = " + idCuenta;
        try {
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ObservableList<CuentaDAO> SELECT() {
        ObservableList<CuentaDAO> list = FXCollections.observableArrayList();
        String query = "SELECT * FROM Cuenta";
        try {
            Statement stmt = Conexion.connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                CuentaDAO c = new CuentaDAO();
                c.setIdCuenta(rs.getInt("idCuenta"));
                c.setIdOrden(rs.getInt("idOrden"));
                c.setMetodoPago(rs.getString("metodoPago"));
                c.setTotal(rs.getDouble("total"));
                c.setCerrada(rs.getBoolean("cerrada"));
                list.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int getIdCuenta() {
        return idCuenta;
    }

    public void setIdCuenta(int idCuenta) {
        this.idCuenta = idCuenta;
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public OrdenDAO getOrden() {
        OrdenDAO obj = null;

        String query = "SELECT * FROM orden WHERE idOrden = " + idOrden;
        try {
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            if (res.next()) {
                obj = new OrdenDAO();

                obj.setIdOrden(res.getInt("idOrden"));
                obj.setIdCliente(res.getInt("idCliente"));
                obj.setFecha(res.getString("fecha"));
                obj.setIdMesa(res.getInt("idMesa"));
                obj.setIdEmpleado(res.getInt("idEmpleado"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return obj;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public boolean isCerrada() {
        return cerrada;
    }

    public void setCerrada(boolean cerrada) {
        this.cerrada = cerrada;
    }

    @Override
    public String toString() {
        return "Cuenta #" + idCuenta + " | Total: $" + total + " | " + (cerrada ? "Cerrada" : "Abierta");
    }
}
