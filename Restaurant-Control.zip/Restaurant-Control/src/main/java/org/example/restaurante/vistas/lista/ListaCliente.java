package org.example.restaurante.vistas.lista;

import javafx.scene.Scene;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.restaurante.componentes.BotonAgregar;
import org.example.restaurante.componentes.TablaEntidad;
import org.example.restaurante.modelosEntidad.ClienteDAO;
import org.example.restaurante.vistas.registro.RegistroCliente;

public class ListaCliente extends Stage {

    private TablaEntidad<ClienteDAO, RegistroCliente> tbeCliente;
    private ClienteDAO objCliente;
    private RegistroCliente rgCliente;
    private Scene scene;
    private VBox vbox;
    private ToolBar tlbMenu;
    private BotonAgregar btnAgregar;

    public void crearUI(){
        tbeCliente = new TablaEntidad<>();

        tbeCliente.setColumna("Nombre", "nombre");
        tbeCliente.setColumna("Dirección", "direccion");
        tbeCliente.setColumna("Teléfono", "telefono");
        tbeCliente.setColumna("Correo", "email");

        objCliente = new ClienteDAO();
        rgCliente = new RegistroCliente(tbeCliente, false);

        tbeCliente.crearTabla(objCliente, rgCliente);

        btnAgregar = new BotonAgregar();
        btnAgregar.setOnAction(actionEvent -> new RegistroCliente(tbeCliente, true));

        tlbMenu = new ToolBar(btnAgregar);

        vbox = new VBox(tlbMenu, tbeCliente);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/tableStyle.css").toString());
    }

    public ListaCliente() {
        crearUI();
        this.setTitle("Lista de Clientes");
        this.setMaximized(true);
        this.setScene(scene);
        this.show();
    }
}
