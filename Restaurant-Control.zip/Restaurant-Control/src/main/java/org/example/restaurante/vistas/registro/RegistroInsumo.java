package org.example.restaurante.vistas.registro;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.example.restaurante.componentes.SelectHora;
import org.example.restaurante.componentes.TxtRegistro;
import org.example.restaurante.modelos.Registro;
import org.example.restaurante.modelosEntidad.InsumoDAO;
import org.example.restaurante.modelosEntidad.ProveedorDAO;

public class RegistroInsumo extends Stage implements Registro<InsumoDAO>{
        private Text title;
        private ComboBox<ProveedorDAO> cmbProveedor;
        private TxtRegistro txtNombre, txtCosto;
        private Button btnGuardar;
        private VBox vbox;
        private Scene scene;
        private InsumoDAO obj;
        private TableView<InsumoDAO> tbvInsumo;

        public void crearUI(){
            title = new Text("Insumo");
            title.getStyleClass().add("title");

            ProveedorDAO objProveedor = new ProveedorDAO();
            cmbProveedor = new ComboBox<>();
            cmbProveedor.setItems(objProveedor.SELECT());

            txtNombre = new TxtRegistro("Nombre Insumo", "txtField");

            txtCosto = new TxtRegistro("Costo Insumo", "txtField");

            btnGuardar = new Button("Guardar");
            btnGuardar.getStyleClass().add("btnGuardar");
            btnGuardar.setOnAction(e -> {
                obj.setIdProveedor(cmbProveedor.getValue().getIdProveedor());
                obj.setNombre(txtNombre.getText());
                obj.setCosto(Double.parseDouble(txtCosto.getText()));

                if(obj.getIdInsumo() > 0)
                    obj.UPDATE();
                else
                    obj.INSERT();

                tbvInsumo.setItems(obj.SELECT());
                tbvInsumo.refresh();

                this.close();
            });

            vbox = new VBox(title, cmbProveedor, txtNombre, txtCosto,btnGuardar);
            vbox.getStyleClass().add("vboxBody");
            vbox.setSpacing(10);
            vbox.setPadding(new Insets(10, 10, 20, 10));
            vbox.setAlignment(Pos.TOP_CENTER);

            scene = new Scene(vbox);
            scene.getStylesheets().add(getClass().getResource("/styles/registroStyle.css").toString());

        }

        public void llenar(InsumoDAO obj){
            this.obj = obj;

            ProveedorDAO proveedor = new ProveedorDAO();


            for (ProveedorDAO p : proveedor.SELECT()) {
                if (p.getIdProveedor() == obj.getIdProveedor()) {
                    proveedor = p;
                    break;
                }
            }

            cmbProveedor.setValue(proveedor);
            txtNombre.setText(obj.getNombre());
            txtCosto.setText(Double.toString(obj.getCosto()));

            this.show();
        }

        public RegistroInsumo(TableView<InsumoDAO> tbvInsumo, boolean show){
            this.tbvInsumo = tbvInsumo;
            obj = new InsumoDAO();

            crearUI();

            this.setMinWidth(320);
            this.setTitle("Registro Insumo");
            this.setScene(scene);

            if(show)
                this.show();
        }
}
