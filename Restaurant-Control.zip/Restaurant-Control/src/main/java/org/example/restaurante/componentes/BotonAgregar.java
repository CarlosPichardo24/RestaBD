package org.example.restaurante.componentes;

import javafx.scene.control.Button;
import javafx.scene.image.ImageView;

public class BotonAgregar extends Button {
    public BotonAgregar() {
        ImageView imvAgregar = new ImageView(getClass().getResource("/iconos/iconoAgregar.png").toString());
        imvAgregar.setFitHeight(25);
        imvAgregar.setFitWidth(25);
        this.setGraphic(imvAgregar);
    }
}
