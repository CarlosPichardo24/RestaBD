package org.example.restaurante.vistas.lista;

import javafx.scene.Scene;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.restaurante.componentes.BotonAgregar;
import org.example.restaurante.componentes.TablaEntidad;
import org.example.restaurante.modelosEntidad.InsumoDAO;
import org.example.restaurante.vistas.registro.RegistroInsumo;

public class ListaInsumo extends Stage {
    private TablaEntidad<InsumoDAO, RegistroInsumo> tbeInsumo;
    private InsumoDAO objInsumo;
    private RegistroInsumo rgInsumo;
    private VBox vbox;
    private ToolBar tlbMenu;
    private BotonAgregar btnAgregar;
    private Scene scene;

    public void crearUI(){
        tbeInsumo = new TablaEntidad<>();
        objInsumo = new InsumoDAO();

        tbeInsumo.setColumna("Nombre", "nombre");
        tbeInsumo.setColumna("Costo", "costo");
        tbeInsumo.setColumna("Proveedor", "nomProveedor");

        rgInsumo = new RegistroInsumo(tbeInsumo, false);

        tbeInsumo.crearTabla(objInsumo, rgInsumo);

        btnAgregar = new BotonAgregar();
        btnAgregar.setOnAction(e -> new RegistroInsumo(tbeInsumo, true));

        tlbMenu = new ToolBar(btnAgregar);

        vbox = new VBox(tlbMenu, tbeInsumo);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/tableStyle.css").toString());
    }

    public ListaInsumo() {
        crearUI();
        this.setTitle("Lista de Insumos");
        this.setMaximized(true);
        this.setScene(scene);
        this.show();
    }
}
