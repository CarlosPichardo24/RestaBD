package org.example.restaurante.vistas.registro;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.restaurante.componentes.TipoPago;
import org.example.restaurante.modelosEntidad.CuentaDAO;

public class MetodoPago extends Stage {
    private Scene escena;
    private ComboBox<TipoPago> cmbMetodo;
    private CuentaDAO cuenta;
    private Button btnFinalizar, btnCancelar;
    private HBox botones;
    private VBox menu;
    private Label header;

    public MetodoPago(CuentaDAO cuenta) {
        this.cuenta = cuenta;
        crearUI();
        this.setScene(escena);
        this.setTitle("Selecciona Método de Pago");
        this.show();
    }

    public Button btnMenu(String text, String url) {
        ImageView imv = new ImageView(getClass().getResource(url).toString());
        imv.setFitHeight(35);
        imv.setFitWidth(35);

        Button btn = new Button(text, imv);

        btn.getStyleClass().add(text.equals("Cancelar")?"btnNo":"btnSi" );

        return btn;
    }

    public void crearUI() {
        header = new Label("Metodo de Pago");
        header.getStyleClass().add("title");
        btnCancelar = btnMenu("Cancelar","/iconos/iconoCancelar.png");
        btnFinalizar = btnMenu("Confirmar","/iconos/iconoConfirmar.png");
        botones = new HBox(btnCancelar,btnFinalizar);
        botones.setPadding(new Insets(5,5,5,5));
        botones.setAlignment(Pos.BASELINE_CENTER);

        cmbMetodo = new ComboBox<>();
        cmbMetodo.getItems().addAll(
                new TipoPago("Tarjeta", "/iconos/iconoTarjeta.png"),
                new TipoPago("Efectivo", "/iconos/iconoDinero.png"),
                new TipoPago("Transferencia", "/iconos/iconoTransferencia.png")
        );

        cmbMetodo.setCellFactory(param -> new TipoPagoCell());
        cmbMetodo.setButtonCell(new TipoPagoCell());

        btnCancelar.setOnAction(
                e -> this.close()
        );

        btnFinalizar.setOnAction(e -> {
            TipoPago seleccionado = cmbMetodo.getSelectionModel().getSelectedItem();
            if (seleccionado != null) {
                cuenta.setMetodoPago(seleccionado.getNombre());
                cuenta.setCerrada(true);
                cuenta.UPDATE();
                this.close(); // cerrar ventana
            }
        });


        menu = new VBox(header,cmbMetodo,botones);
        menu.setPadding(new Insets(20,20,20,20));
        escena = new Scene(menu);
        escena.getStylesheets().add(getClass().getResource("/styles/registroCuenta.css").toString());
    }
}


class TipoPagoCell extends ListCell<TipoPago> {
    @Override
    protected void updateItem(TipoPago item, boolean empty) {
        super.updateItem(item, empty);
        if (empty || item == null) {
            setGraphic(null);
            setText(null);
        } else {
            Image img = new Image(getClass().getResourceAsStream(item.getRutaImagen()));
            ImageView imageView = new ImageView(img);
            imageView.setFitWidth(200);
            imageView.setFitHeight(100);

            setGraphic(imageView);
            setText(item.getNombre());
        }
    }
}
