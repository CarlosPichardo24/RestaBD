package org.example.restaurante.vistas;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import org.example.restaurante.modelosEntidad.MejorEmpleadoDAO;

import java.io.InputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MejorEmpleado extends Stage {

    private MejorEmpleadoDAO obj;

    public MejorEmpleado() {
        obj = new MejorEmpleadoDAO().SELECT();
        crearUI();
    }

    private void crearUI() {
        TabPane tabPanePrincipal = new TabPane();

        Tab tabInfo = new Tab("Información");
        tabInfo.setContent(crearPanelInformacion());
        tabInfo.setClosable(false);

        Tab tabMetricas = new Tab("Métricas");
        tabMetricas.setContent(crearPanelMetricas());
        tabMetricas.setClosable(false);

        tabPanePrincipal.getTabs().addAll(tabInfo, tabMetricas);

        Scene scene = new Scene(tabPanePrincipal);
        scene.getStylesheets().add(getClass().getResource("/styles/empleadoStyle.css").toString());
        this.setScene(scene);
    }

    private Node crearPanelInformacion() {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(20);
        grid.setVgap(15);

        VBox fotoBox = new VBox(10);
        fotoBox.setAlignment(Pos.CENTER);

        ImageView imageView = loadEmployeeBadgeImage();
        Label lblReconocimiento = new Label("★ EMPLEADO DESTACADO ★");
        lblReconocimiento.setStyle("-fx-text-fill: gold; -fx-font-weight: bold;");

        fotoBox.getChildren().addAll(imageView, lblReconocimiento);
        grid.add(fotoBox, 0, 0, 1, 4);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

        grid.add(crearCampoInformacion("Nombre:", obj.getEmpleado()), 1, 0);
        grid.add(crearCampoInformacion("Puesto:", obj.getPuesto()), 1, 1);
        grid.add(crearCampoInformacion("ID Empleado:", String.valueOf(obj.getId())), 1, 2);
        grid.add(crearCampoInformacion("Última venta:", sdf.format(obj.getUltima_venta())), 1, 3);

        return new ScrollPane(grid);
    }

    private ImageView loadEmployeeBadgeImage() {
        String[] possiblePaths = {
                "/iconos/reconocimiento.png",
                "/images/reconocimiento.png",
                "iconos/reconocimiento.png",
                "images/reconocimiento.png"
        };

        for (String path : possiblePaths) {
            try (InputStream is = getClass().getResourceAsStream(path)) {
                if (is != null) {
                    Image image = new Image(is);
                    ImageView imageView = new ImageView(image);
                    imageView.setFitHeight(150);
                    imageView.setFitWidth(150);
                    return imageView;
                }
            } catch (Exception e) {
                System.err.println("Error al cargar imagen desde " + path + ": " + e.getMessage());
            }
        }

        return createPlaceholderImageView();
    }

    private ImageView createPlaceholderImageView() {
        ImageView imageView = new ImageView();
        imageView.setFitHeight(150);
        imageView.setFitWidth(150);
        imageView.setStyle("-fx-background-color: lightgray;");
        return imageView;
    }

    private Node crearCampoInformacion(String titulo, String valor) {
        HBox hbox = new HBox(10);
        Label lblTitulo = new Label(titulo);
        lblTitulo.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");
        Label lblValor = new Label(valor);
        lblValor.setStyle("-fx-font-size: 14;");
        hbox.getChildren().addAll(lblTitulo, lblValor);
        return hbox;
    }

    private Node crearPanelMetricas() {
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);

        VBox vbox = new VBox(20);
        vbox.setPadding(new Insets(20));

        GridPane gridMetricas = new GridPane();
        gridMetricas.setHgap(20);
        gridMetricas.setVgap(20);
        gridMetricas.setPadding(new Insets(10));

        gridMetricas.add(crearTarjetaMetrica("Ventas Totales", currencyFormat.format(obj.getTotal_vendido()), "#3E5058"), 0, 0);
        gridMetricas.add(crearTarjetaMetrica("Órdenes Realizadas", numberFormat.format(obj.getOrdenes_realizadas()), "#D97706"), 1, 0);
        gridMetricas.add(crearTarjetaMetrica("Promedio por Orden", currencyFormat.format(obj.getPromedio_por_orden()), "#D97706"), 0, 1);
        gridMetricas.add(crearTarjetaMetrica("Eficiencia", calcularEficiencia(), "#3E5058"), 1, 1);

        vbox.getChildren().add(gridMetricas);
        return new ScrollPane(vbox);
    }

    private String calcularEficiencia() {
        double eficiencia = (obj.getPromedio_por_orden() / 150) * 100;
        return String.format("%.1f%%", Math.min(eficiencia, 100));
    }

    private Node crearTarjetaMetrica(String titulo, String valor, String color) {
        VBox tarjeta = new VBox(5);
        tarjeta.setAlignment(Pos.CENTER);
        tarjeta.setPadding(new Insets(15));
        tarjeta.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 10;");

        Label lblTitulo = new Label(titulo);
        lblTitulo.setStyle("-fx-font-weight: bold; -fx-text-fill: white; -fx-font-size: 14;");

        Label lblValor = new Label(valor);
        lblValor.setStyle("-fx-text-fill: white; -fx-font-size: 18; -fx-font-weight: bold;");

        tarjeta.getChildren().addAll(lblTitulo, lblValor);
        return tarjeta;
    }

    public Node getContent() {
        VBox content = new VBox();

        TabPane tabPane = new TabPane();

        Tab tabInfo = new Tab("Información");
        tabInfo.setContent(crearPanelInformacion());
        tabInfo.setClosable(false);

        Tab tabMetricas = new Tab("Métricas");
        tabMetricas.setContent(crearPanelMetricas());
        tabMetricas.setClosable(false);

        tabPane.getTabs().addAll(tabInfo, tabMetricas);
        content.getChildren().add(tabPane);

        return content;
    }
}
