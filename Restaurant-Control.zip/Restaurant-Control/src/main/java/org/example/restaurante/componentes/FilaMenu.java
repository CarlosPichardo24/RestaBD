package org.example.restaurante.componentes;

import javafx.scene.layout.HBox;

class FilaMenu extends HBox {
    private int m;
    private int cont;
    FilaMenu sig;

    public boolean addBtn(BtnMenu btn) {
        boolean res = false;

        if (cont < m) {
            this.getChildren().add(btn);
            cont++;
            res = true;
        }

        return res;
    }

    public FilaMenu(int m) {
        this.m = m;
        cont = 0;
        sig = null;
    }
}
