package org.example.restaurante.vistas.registro;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.example.restaurante.componentes.TxtRegistro;
import org.example.restaurante.modelos.Registro;
import org.example.restaurante.modelosEntidad.ProveedorDAO;

public class RegistroProveedor extends Stage implements Registro<ProveedorDAO> {

    private Text title;
    private TxtRegistro txtNombre, txtDireccion, txtTelefono, txtEmail;
    private Button btnGuardar;
    private ProveedorDAO obj;
    private TableView<ProveedorDAO> tbvProveedor;
    private VBox vbox;
    private Scene scene;


    public void crearUI() {
        title = new Text("Proveedor");
        title.getStyleClass().add("title");

        txtNombre = new TxtRegistro("Nombre Proveedor", "txtField");
        txtTelefono = new TxtRegistro("Telefono Proveedor", "txtField");
        txtDireccion = new TxtRegistro("Direccion Proveedor", "txtField");
        txtEmail = new TxtRegistro("Email Proveedor", "txtField");

        btnGuardar = new Button("Guardar");
        btnGuardar.getStyleClass().add("btnGuardar");
        btnGuardar.setOnAction(e -> {
            obj.setNombre(txtNombre.getText());
            obj.setTelefono(txtTelefono.getText());
            obj.setDireccion(txtDireccion.getText());
            obj.setEmail(txtEmail.getText());

            if(obj.getIdProveedor() > 0)
                obj.UPDATE();

            else
                obj.INSERT();

            tbvProveedor.setItems(obj.SELECT());
            tbvProveedor.refresh();

            this.close();
        });

        vbox = new VBox(title, txtNombre, txtTelefono, txtDireccion, txtEmail, btnGuardar);
        vbox.getStyleClass().add("vboxBody");
        vbox.setPadding(new Insets(10, 15, 20, 15));
        vbox.setSpacing(10);
        vbox.setAlignment(Pos.TOP_CENTER);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/registroStyle.css").toString());
    }

    public void llenar(ProveedorDAO obj) {
        this.obj = obj;

        txtNombre.setText(obj.getNombre());
        txtTelefono.setText(obj.getTelefono());
        txtDireccion.setText(obj.getDireccion());
        txtEmail.setText(obj.getEmail());

        this.show();
    }

    public RegistroProveedor(TableView<ProveedorDAO> tbvProveedor, boolean show){
        this.tbvProveedor = tbvProveedor;
        obj = new ProveedorDAO();

        crearUI();

        this.setTitle("Proveedor");
        this.setMinWidth(320);
        this.setScene(scene);
        if(show)
            this.show();
    }
}
