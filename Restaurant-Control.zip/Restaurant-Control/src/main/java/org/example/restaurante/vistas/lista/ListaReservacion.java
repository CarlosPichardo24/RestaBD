package org.example.restaurante.vistas.lista;

import javafx.scene.Scene;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.restaurante.componentes.BotonAgregar;
import org.example.restaurante.componentes.TablaEntidad;
import org.example.restaurante.modelosEntidad.InsumoDAO;
import org.example.restaurante.modelosEntidad.ReservacionDAO;
import org.example.restaurante.vistas.registro.RegistroInsumo;
import org.example.restaurante.vistas.registro.RegistroReservacion;

public class ListaReservacion extends Stage {
    private TablaEntidad<ReservacionDAO, RegistroReservacion> tbeReservacion;
    private ReservacionDAO objReservacion;
    private RegistroReservacion rgReservacion;
    private VBox vbox;
    private ToolBar tlbMenu;
    private BotonAgregar btnAgregar;
    private Scene scene;

    public void crearUI(){
        tbeReservacion = new TablaEntidad<>();
        objReservacion = new ReservacionDAO();

        tbeReservacion.setColumna("Cliente", "nomCliente");
        tbeReservacion.setColumna("Fecha", "fechaReservacion");
        tbeReservacion.setColumna("Hora", "horaReservacion");

        rgReservacion = new RegistroReservacion(tbeReservacion, false);

        tbeReservacion.crearTabla(objReservacion, rgReservacion);

        btnAgregar = new BotonAgregar();
        btnAgregar.setOnAction(e -> new RegistroReservacion(tbeReservacion, true));

        tlbMenu = new ToolBar(btnAgregar);

        vbox = new VBox(tlbMenu, tbeReservacion);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/tableStyle.css").toString());
    }

    public ListaReservacion() {
        crearUI();
        this.setTitle("Lista de Reservaciones");
        this.setMaximized(true);
        this.setScene(scene);
        this.show();
    }
}
