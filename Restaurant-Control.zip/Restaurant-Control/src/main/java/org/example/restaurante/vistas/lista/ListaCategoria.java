package org.example.restaurante.vistas.lista;

import javafx.scene.Scene;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.restaurante.componentes.BotonAgregar;
import org.example.restaurante.componentes.TablaEntidad;
import org.example.restaurante.modelosEntidad.CategoriaDAO;
import org.example.restaurante.vistas.registro.RegistroCategoria;

public class ListaCategoria extends Stage {
    private TablaEntidad<CategoriaDAO, RegistroCategoria> tbeCategoria;
    private Scene scene;
    private VBox vbox;
    private ToolBar tlbMenu;
    private BotonAgregar btnAgregar;
    private CategoriaDAO objCategoria;
    private RegistroCategoria rgCategoria;

    public void crearUI(){
        tbeCategoria = new TablaEntidad<>();

        tbeCategoria.setColumna("Nombre", "nombre");
        tbeCategoria.setColumna("Descripción", "descripcion");

        objCategoria = new CategoriaDAO();
        rgCategoria = new RegistroCategoria(tbeCategoria, false);

        tbeCategoria.crearTabla(objCategoria, rgCategoria);

        btnAgregar = new BotonAgregar();
        btnAgregar.setOnAction(e -> new RegistroCategoria(tbeCategoria, true));
        tlbMenu = new ToolBar(btnAgregar);

        vbox = new VBox(tlbMenu, tbeCategoria);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/tableStyle.css").toString());
    }

    public ListaCategoria() {
        crearUI();
        this.setTitle("Lista de Categorias");
        this.setMaximized(true);
        this.setScene(scene);
        this.show();
    }
}
