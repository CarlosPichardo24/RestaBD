package org.example.restaurante.vistas.registro;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.example.restaurante.componentes.TxtRegistro;
import org.example.restaurante.modelos.Registro;
import org.example.restaurante.modelosEntidad.MesaDAO;

public class RegistroMesa extends Stage implements Registro<MesaDAO> {
    private Text title;
    private TxtRegistro txtNombre, txtCapacidad;
    private Button btnGuardar;
    private VBox vbox;
    private Scene scene;
    private MesaDAO obj;
    private TableView<MesaDAO> tbvMesa;

    public void crearUI(){
        title = new Text("Mesa");
        title.getStyleClass().add("title");

        txtNombre = new TxtRegistro("Nombre Mesa", "txtField");
        txtCapacidad = new TxtRegistro("Capacidad Mesa", "txtField");

        btnGuardar = new Button("Guardar");
        btnGuardar.getStyleClass().add("btnGuardar");
        btnGuardar.setOnAction(e -> {
            obj.setNombre(txtNombre.getText());
            obj.setCapacidad(Integer.parseInt(txtCapacidad.getText()));

            if(obj.getIdMesa() > 0)
                obj.UPDATE();
            else
                obj.INSERT();

            tbvMesa.setItems(obj.SELECT());
            tbvMesa.refresh();

            this.close();
        });

        vbox = new VBox(title, txtNombre, txtCapacidad,btnGuardar);
        vbox.getStyleClass().add("vboxBody");
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(10, 10, 20, 10));
        vbox.setAlignment(Pos.TOP_CENTER);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/registroStyle.css").toString());

    }

    public void llenar(MesaDAO obj){
        this.obj = obj;

        txtNombre.setText(obj.getNombre());
        txtCapacidad.setText(String.valueOf(obj.getCapacidad()));

        this.show();
    }

    public RegistroMesa(TableView<MesaDAO> tbvMesa, boolean show){
        this.tbvMesa = tbvMesa;
        obj = new MesaDAO();

        crearUI();

        this.setMinWidth(320);
        this.setTitle("Registro Mesa");
        this.setScene(scene);

        if(show)
            this.show();
    }
}
