
        package org.example.restaurante.modelosEntidad;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.restaurante.modelos.Conexion;
import org.example.restaurante.modelos.Entidad;
import org.example.restaurante.modelos.Nombrable;

import java.sql.ResultSet;
import java.sql.Statement;

public class MesaDAO implements Entidad<MesaDAO>, Nombrable {
    private int idMesa;
    private String nombre;
    private int capacidad;

    public void INSERT(){
        String query = "INSERT INTO mesa (nombre, capacidad) " +
                "VALUES ('"+nombre+"', "+capacidad+")";
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void UPDATE(){
        String query = "UPDATE mesa SET " +
                "nombre = '"+nombre+"', " +
                "capacidad = "+capacidad+" " +
                "WHERE idMesa = "+idMesa;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void DELETE(){
        String query = "DELETE FROM mesa WHERE idMesa = "+idMesa;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ObservableList<MesaDAO> SELECT(){
        String query = "SELECT * FROM mesa";
        ObservableList<MesaDAO> list = FXCollections.observableArrayList();
        MesaDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new MesaDAO();

                obj.setIdMesa(res.getInt("idMesa"));
                obj.setNombre(res.getString("nombre"));
                obj.setCapacidad(res.getInt("capacidad"));

                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public int getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(int idMesa) {
        this.idMesa = idMesa;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    @Override
    public String toString(){
        return nombre;
    }
}
