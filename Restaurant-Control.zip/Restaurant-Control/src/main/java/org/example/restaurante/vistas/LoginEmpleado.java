package org.example.restaurante.vistas;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.example.restaurante.modelos.Conexion;
import org.example.restaurante.modelosEntidad.CategoriaDAO;
import org.example.restaurante.modelosEntidad.EmpleadoDAO;

import javax.swing.*;
import java.sql.Connection;
import java.sql.SQLException;

public class LoginEmpleado extends Stage {
    private Text title;
    private TextField txtNombre, txtContrasena;
    private Button btnLogin;
    private Teclado tec;
    private VBox vbox;
    private Scene scene;

    public void crearUI(){
        title = new Text("Login Restaurante Control");
        title.getStyleClass().add("title");


        txtNombre = new TextField();
        txtNombre.setPromptText("Nombre");
        txtNombre.getStyleClass().add("txtField");
        txtNombre.setOnMouseClicked(e -> Teclado.asociarCampo(txtNombre));


        txtContrasena = new TextField();
        txtContrasena.setPromptText("Contrasena");
        txtContrasena.getStyleClass().add("txtField");
        txtContrasena.setOnMouseClicked(e -> Teclado.asociarCampo(txtContrasena));

        btnLogin = new Button("Acceder");
        btnLogin.getStyleClass().add("btnGuardar");


        btnLogin.setOnAction(e -> {
            if (txtNombre.getText().equals(Conexion.getUSER()) && txtContrasena.getText().equals(Conexion.getPWD()))
                this.close();
            else
            {
                JOptionPane.showMessageDialog(null,"ola");
            }
        });

        vbox = new VBox(title, txtNombre, txtContrasena, btnLogin);
        vbox.getStyleClass().add("vboxBody");
        vbox.setPadding(new Insets(10, 10, 20, 10));
        vbox.setSpacing(10);
        vbox.setAlignment(Pos.TOP_CENTER);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/registroStyle.css").toString());
    }

    public LoginEmpleado() {
        crearUI();
        this.setMinWidth(320);
        this.setTitle("Categoria");
        this.setScene(scene);
         this.show();
    }
}
