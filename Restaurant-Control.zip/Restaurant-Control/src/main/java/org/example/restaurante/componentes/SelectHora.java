package org.example.restaurante.componentes;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

public class SelectHora extends VBox {

    private Text title;
    private ComboBox<String> cmbHora;
    private ComboBox<String> cmbMinuto;
    private HBox hBoxContenedor;

    public SelectHora(String strTitle) {
        title = new Text(strTitle);
        title.setStyle("-fx-font-size: 15px;");

        cmbHora = new ComboBox<>();
        for (int i = 0; i < 24; i++) {
            cmbHora.getItems().add(String.format("%02d", i));
        }
        cmbHora.setVisibleRowCount(5);
        cmbHora.setPromptText("Hora");

        cmbMinuto = new ComboBox<>();
        for (int i = 0; i < 60; i++) {
            cmbMinuto.getItems().add(String.format("%02d", i));
        }
        cmbMinuto.setVisibleRowCount(5);
        cmbMinuto.setPromptText("Minuto");

        hBoxContenedor = new HBox(cmbHora, cmbMinuto);
        hBoxContenedor.setSpacing(10);
        hBoxContenedor.setAlignment(Pos.CENTER_LEFT);

        this.getChildren().addAll(title, hBoxContenedor);
        this.setSpacing(5);
        this.setPadding(new Insets(2));
    }

    public String getHora() {
        return cmbHora.getValue();
    }

    public String getMinuto() {
        return cmbMinuto.getValue();
    }

    public String getHoraCompleta() {
        String hora = cmbHora.getValue();
        String minuto = cmbMinuto.getValue();

        if (hora == null || minuto == null) {
            return null;
        }

        return hora + ":" + minuto;
    }

    public void setHora(String hora) {
        cmbHora.setValue(String.format("%02d", Integer.parseInt(hora)));
    }

    public void setMinuto(String minuto) {
        cmbMinuto.setValue(String.format("%02d", Integer.parseInt(minuto)));
    }

    public void setHoraCompleta(String horaCompleta) {
        if (horaCompleta == null || !horaCompleta.contains(":")) return;
        String[] partes = horaCompleta.split(":");
        if (partes.length == 2) {
            setHora(partes[0]);
            setMinuto(partes[1]);
        }
    }
}
