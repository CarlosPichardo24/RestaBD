package org.example.restaurante.vistas;

import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.stage.Stage;

public class Estadisticas extends Stage {

    private Scene scene;
    private TabPane tabPanePrincipal;

    public Estadisticas() {
        crearUI();
        this.setTitle("Estadisticas");
        this.setMaximized(true);
        this.setScene(scene);
        this.show();
    }

    public void crearUI() {
        tabPanePrincipal = new TabPane();


        Tab tabMejorEmpleado = new Tab("Mejor Empleado");
        tabMejorEmpleado.setContent(new MejorEmpleado().getContent());
        tabMejorEmpleado.setClosable(false);

        Tab tabVentasDiarias = new Tab("Ventas Diarias");
        tabVentasDiarias.setContent(new VentasDiarias().getContent());
        tabVentasDiarias.setClosable(false);

        Tab tabTopProductos = new Tab("Top Productos");
        tabTopProductos.setContent(new TopProductosVendidos().getContent());
        tabTopProductos.setClosable(false);

        tabPanePrincipal.getTabs().addAll(tabVentasDiarias, tabTopProductos, tabMejorEmpleado);
        tabPanePrincipal.getStyleClass().add("tab-pane");

        scene = new Scene(tabPanePrincipal);
        scene.getStylesheets().add(getClass().getResource("/styles/tableStyle.css").toString());
        scene.getStylesheets().add(getClass().getResource("/styles/labelStyle.css").toString());
        scene.getStylesheets().add(getClass().getResource("/styles/tabStyle.css").toString());


    }
}