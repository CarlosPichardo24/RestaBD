package org.example.restaurante.modelos;

public interface Nombrable {
    String getNombre();
}
