package org.example.restaurante.modelosEntidad;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.restaurante.modelos.Conexion;
import org.example.restaurante.modelos.Entidad;

import java.sql.ResultSet;
import java.sql.Statement;

public class ReservacionDAO implements Entidad<ReservacionDAO> {
    private int idReservacion;
    private int idCliente;
    private String fechaReservacion;
    private String horaReservacion;

    private String nomCliente;

    public void INSERT(){
        String query = "INSERT INTO reservacion (idCliente, fechaReservacion, horaReservacion) " +
                "VALUES ("+idCliente+", '"+fechaReservacion+"', '"+horaReservacion+"')";
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void UPDATE(){
        String query = "UPDATE reservacion SET " +
                "idCliente = "+idCliente+", " +
                "fechaReservacion = '"+fechaReservacion+"', " +
                "horaReservacion = '"+horaReservacion+"' " +
                "WHERE idReservacion = "+idReservacion;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void DELETE(){
        String query = "DELETE FROM reservacion WHERE idReservacion = "+idReservacion;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ObservableList<ReservacionDAO> SELECT(){
        String query = "SELECT * FROM reservacion";
        ObservableList<ReservacionDAO> list = FXCollections.observableArrayList();
        ReservacionDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new ReservacionDAO();

                obj.setIdReservacion(res.getInt("idReservacion"));
                obj.setIdCliente(res.getInt("idCliente"));
                obj.setFechaReservacion(res.getString("fechaReservacion"));
                obj.setHoraReservacion(res.getString("horaReservacion"));

                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public int getIdReservacion() {
        return idReservacion;
    }

    public void setIdReservacion(int idReservacion) {
        this.idReservacion = idReservacion;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
        setNomCliente();
    }

    public String getNomCliente(){
        return nomCliente;
    }
    public void setNomCliente() {
        String query = "SELECT * FROM cliente WHERE idCliente = "+idCliente;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            if (res.next()) {
                nomCliente = res.getString("nombre");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getFechaReservacion() {
        return fechaReservacion;
    }

    public void setFechaReservacion(String fechaReservacion) {
        this.fechaReservacion = fechaReservacion;
    }

    public String getHoraReservacion() {
        return horaReservacion;
    }

    public void setHoraReservacion(String horaReservacion) {
        this.horaReservacion = horaReservacion;
    }
}
