package org.example.restaurante.modelosEntidad;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.restaurante.modelos.Conexion;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class OrdenDAO {
    private int idOrden;
    private Integer idCliente;
    private String fecha;
    private int idMesa;
    private int idEmpleado;

    public void INSERT() {
        String query = "INSERT INTO orden (idCliente, fecha, idMesa, idEmpleado) " +
                "VALUES (" + idCliente + ", '" + fecha + "', " + idMesa + ", " + idEmpleado + ")";
        try {
            PreparedStatement stmt = Conexion.connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            stmt.executeUpdate();

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    this.idOrden = generatedKeys.getInt(1);
                } else {
                    throw new RuntimeException("Insert failed, no ID obtained.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void UPDATE(){
        String query = "UPDATE orden SET " +
                "idCliente = "+idCliente+", " +
                "fecha = '"+fecha+"', " +
                "idMesa = "+idMesa+", " +
                "idEmpleado = "+idEmpleado+" " +
                "WHERE idOrden = "+idOrden;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void DELETE(){
        String query = "DELETE FROM orden WHERE idOrden = "+idOrden;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ObservableList<OrdenDAO> SELECT(){
        String query = "SELECT * FROM orden";
        ObservableList<OrdenDAO> list = FXCollections.observableArrayList();
        OrdenDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new OrdenDAO();

                obj.setIdOrden(res.getInt("idOrden"));
                obj.setIdCliente(res.getInt("idCliente"));
                obj.setFecha(res.getString("fecha"));
                obj.setIdMesa(res.getInt("idMesa"));
                obj.setIdEmpleado(res.getInt("idEmpleado"));

                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public ClienteDAO getCliente() {
        ClienteDAO obj = null;

        String query = "SELECT * FROM cliente WHERE idCliente = " + idCliente;
        try {
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            if (res.next()) {
                obj = new ClienteDAO();

                obj.setIdCliente(res.getInt("idCliente"));
                obj.setNombre(res.getString("nombre"));
                obj.setDireccion(res.getString("direccion"));
                obj.setTelefono(res.getString("telefono"));
                obj.setEmail(res.getString("email"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return obj;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(int idMesa) {
        this.idMesa = idMesa;
    }

    public MesaDAO getMesa() {
        MesaDAO obj = null;

        String query = "SELECT * FROM mesa WHERE idMesa = " + idMesa;
        try {
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            if (res.next()) {
                obj = new MesaDAO();

                obj.setIdMesa(res.getInt("idMesa"));
                obj.setNombre(res.getString("nombre"));
                obj.setCapacidad(res.getInt("capacidad"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return obj;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public EmpleadoDAO getEmpleado() {
        EmpleadoDAO obj = null;

        String query = "SELECT * FROM emplado WHERE idEmpleado = " + idEmpleado;
        try {
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            if (res.next()) {
                obj = new EmpleadoDAO();

                obj.setIdEmpleado(res.getInt("idEmpleado"));
                obj.setNombre(res.getString("nombre"));
                obj.setApellido(res.getString("apellido"));
                obj.setCurp(res.getString("curp"));
                obj.setRfc(res.getString("rfc"));
                obj.setSueldo(res.getDouble("sueldo"));
                obj.setPuesto(res.getString("puesto"));
                obj.setTelefono(res.getString("telefono"));
                obj.setHorario(res.getString("horario"));
                obj.setFechaIngreso(res.getString("fechaIngreso"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return obj;
    }
}
