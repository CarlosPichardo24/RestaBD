package org.example.restaurante.modelosEntidad;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.restaurante.modelos.Conexion;
import org.example.restaurante.modelos.Entidad;
import org.example.restaurante.modelos.Nombrable;

import java.sql.ResultSet;
import java.sql.Statement;

public class CategoriaDAO implements Entidad<CategoriaDAO>, Nombrable {
    private int idCategoria;
    private String nombre;
    private String descripcion;

    public void INSERT(){
        String query = "INSERT INTO categoria (nombre, descripcion) " +
                "VALUES ('"+nombre+"', '"+descripcion+"')";
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void UPDATE(){
        String query = "UPDATE categoria SET " +
                "nombre = '"+nombre+"', " +
                "descripcion = '"+descripcion+"' " +
                "WHERE idCategoria = "+idCategoria;

        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void DELETE(){
        String query = "DELETE FROM categoria WHERE idCategoria = "+idCategoria;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public ObservableList<CategoriaDAO> SELECT(){
        String query = "SELECT * FROM categoria";
        ObservableList<CategoriaDAO> list = FXCollections.observableArrayList();
        CategoriaDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new CategoriaDAO();

                obj.setIdCategoria(res.getInt("idCategoria"));
                obj.setNombre(res.getString("nombre"));
                obj.setDescripcion(res.getString("descripcion"));

                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public String toString() {
        return nombre;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
