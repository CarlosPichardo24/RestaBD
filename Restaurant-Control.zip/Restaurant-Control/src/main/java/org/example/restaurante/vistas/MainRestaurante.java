package org.example.restaurante.vistas;

import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.SVGPath;
import javafx.stage.Stage;
import org.example.restaurante.modelos.Conexion;
import org.example.restaurante.modelos.GenerarReporte;
import org.example.restaurante.vistas.lista.*;
public class MainRestaurante extends Stage {

    private Button btnComedor, btnReporte, btnEstadisticas, btnTec, btnExpandir, btnEmpleados, btnClientes, btnProductos, btnInsumos, btnProveedores, btnMesas, btnCategoria, btnReservacion;
    private VBox vMenu, vDesplegable, vRight;
    private HBox hExpandir;
    private ImageView imvLogo;

    private BorderPane root;
    private Scene scene;

    private Button btnMain(String name, String url){
        ImageView imv = new ImageView(getClass().getResource(url).toString());
        imv.setFitHeight(80);
        imv.setFitWidth(80);

        Button btn = new Button(name, imv);
        btn.getStyleClass().add("btnMain");

        return btn;
    }

    public void crearMenu(){
        ImageView imvArrow = new ImageView(getClass().getResource("/iconos/iconoArrow.png").toString());
        btnTec = btnMain("Teclado","/iconos/tecladoIcono.png");
        btnTec.setOnAction(e -> new Teclado());

        btnEstadisticas = btnMain("Estadisticas","/iconos/iconoGrafica.png");
        btnEstadisticas.setOnAction(actionEvent -> new TopProductosVendidos());

        btnReporte = btnMain("Reporte","/iconos/reporte.png");
        btnReporte.setOnAction(actionEvent -> new GenerarReporte());

        btnExpandir = new Button("", imvArrow);
        btnExpandir.setId("btnExpandir");

        btnTec = btnMain("Teclado","/iconos/tecladoIcono.png");
        btnTec.setOnAction(e -> new Teclado());

        btnEmpleados = btnMain("Empleados","/iconos/iconoEmpleado.png");
        btnEmpleados.setOnAction(e -> new ListaEmpleado());

        btnClientes = btnMain("Clientes","/iconos/iconoCliente.png");
        btnClientes.setOnAction(e -> new ListaCliente());

        btnProductos = btnMain("Productos", "/iconos/iconoProducto.png");
        btnProductos.setOnAction(e -> new ListaProducto());

        btnInsumos = btnMain("Insumos", "/iconos/iconoInsumo.png");
        btnInsumos.setOnAction(e -> new ListaInsumo());

        btnProveedores = btnMain("Proveedores","/iconos/iconoProveedor.png");
        btnProveedores.setOnAction(e -> new ListaProveedor());

        btnMesas = btnMain("Mesas", "/iconos/iconoMesa.png");
        btnMesas.setOnAction(e -> new ListaMesa());

        btnReservacion = btnMain("Reservacion", "/iconos/iconoReservacion.png");
        btnReservacion.setOnAction(e -> new ListaReservacion());

        btnCategoria = btnMain("Categoria", "/iconos/iconoCategoria.png");
        btnCategoria.setOnAction(e -> new ListaCategoria());

        btnEstadisticas = btnMain("Estadisticas","/iconos/iconoGrafica.png");
        btnEstadisticas.setOnAction(actionEvent -> new Estadisticas());

        btnReporte = btnMain("Reporte","/iconos/reporte.png");
        btnReporte.setOnAction(actionEvent ->
                {
                   GenerarReporte e = new GenerarReporte();
                    e.generarPDFConDialogo(this);
                }
        );

        hExpandir = new HBox(btnExpandir);
        hExpandir.setId("hExpandir");
        hExpandir.setAlignment(Pos.TOP_RIGHT);



        vMenu = new VBox(hExpandir, btnEmpleados, btnClientes, btnProductos, btnInsumos, btnProveedores);
        vMenu.getStyleClass().add("vMenu");

        vDesplegable = new VBox(btnMesas, btnReservacion, btnCategoria, btnEstadisticas, btnReporte);
        vDesplegable.setVisible(false);
        vDesplegable.getStyleClass().add("vMenu");
        vDesplegable.setId("vDesplegable");

        btnExpandir.setOnAction(e -> vDesplegable.setVisible(!vDesplegable.isVisible()));
    }

    public void crearUI(){
        crearMenu();

        imvLogo = new ImageView(getClass().getResource("/iconos/iconoRestaurantG.png").toString());

        btnComedor = btnMain("Comedor", "/iconos/iconoComedor.png");
        btnComedor.setId("btnComedor");
        btnComedor.setOnAction(e -> new Comedor());
        vRight = new VBox(btnComedor);
        vRight.getStyleClass().add("vRight");

        root = new BorderPane();
        root.setLeft(new HBox(vMenu, vDesplegable));
        root.setCenter(imvLogo);
        root.setRight(vRight);

        scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("/styles/mainStyle.css").toString());
    }

    public MainRestaurante() {
        Conexion conexion = new Conexion();
        conexion.crearConnection();

        crearUI();
        this.setMaximized(true);
        this.setTitle("Restaurante");
        this.setScene(scene);
        this.show();
    }
}
