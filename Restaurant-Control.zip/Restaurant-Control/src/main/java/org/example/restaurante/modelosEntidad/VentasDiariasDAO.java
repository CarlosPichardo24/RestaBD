package org.example.restaurante.modelosEntidad;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.restaurante.modelos.Conexion;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;

public class VentasDiariasDAO {
    private int total_ordenes;
    private float total_ventas;
    private Date dia;

    public int getTotal_ordenes() {
        return total_ordenes;
    }

    public void setTotal_ordenes(int total_ordenes) {
        this.total_ordenes = total_ordenes;
    }

    public float getTotal_ventas() {
        return total_ventas;
    }

    public void setTotal_ventas(float total_ventas) {
        this.total_ventas = total_ventas;
    }

    public Date getDia() {
        return dia;
    }

    public void setDia(Date dia) {
        this.dia = dia;
    }

    public ObservableList<VentasDiariasDAO> SELECT()
    {
        String query = "SELECT * from ventadia";
        ObservableList<VentasDiariasDAO> list = FXCollections.observableArrayList();
        VentasDiariasDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new VentasDiariasDAO();
                obj.setTotal_ventas(res.getFloat("total_ventas"));
                obj.setTotal_ordenes(res.getInt("total_ordenes"));
                obj.setDia(res.getDate("dia"));
                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

}
