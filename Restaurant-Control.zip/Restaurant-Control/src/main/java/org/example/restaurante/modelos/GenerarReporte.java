package org.example.restaurante.modelos;

import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.element.*;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.properties.AreaBreakType;
import com.itextpdf.layout.properties.HorizontalAlignment;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.chart.*;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.StackPane;
import javafx.scene.transform.Transform;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.example.restaurante.modelosEntidad.VentaProductosDAO;
import org.example.restaurante.modelosEntidad.VentasDiariasDAO;
import org.example.restaurante.modelosEntidad.MejorEmpleadoDAO;
import org.example.restaurante.vistas.TopProductosVendidos;
import org.example.restaurante.vistas.VentasDiarias;
import org.example.restaurante.vistas.MejorEmpleado;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;

public class GenerarReporte {

    private static final boolean DEBUG_MODE = true; // Cambiar a false en producción
    private final TopProductosVendidos graficaVentas;
    private final VentasDiarias ventasDiarias;
    private final MejorEmpleado mejorEmpleado;
    private String rutaArchivo;

    static {
        // Configuración de renderizado para mejor calidad
        System.setProperty("prism.order", "sw");
        System.setProperty("prism.text", "t2k");
        System.setProperty("prism.subpixeltext", "true");
    }

    public GenerarReporte() {
        this.graficaVentas = new TopProductosVendidos();
        this.graficaVentas.cargarDatosVentas();
        this.ventasDiarias = new VentasDiarias();
        this.ventasDiarias.cargarDatosVentas();
        this.mejorEmpleado = new MejorEmpleado();
    }

    public boolean generarPDFCompleto(String rutaDestino) throws IOException {
        try {
            if (graficaVentas.getDatosVentas().isEmpty() && ventasDiarias.getDatosVentas().isEmpty()) {
                System.err.println("No hay datos para generar el reporte");
                return false;
            }

            this.rutaArchivo = rutaDestino;
            PdfWriter writer = new PdfWriter(rutaArchivo);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            configurarDocumento(document);
            agregarPortada(document);
            agregarResumenEjecutivo(document);
            agregarMejorEmpleado(document);

            // Crear y configurar gráficas de productos vendidos
            BarChart<String, Number> barChart = graficaVentas.crearGraficaBarras();
            barChart.setAnimated(false);

            PieChart pieChart = graficaVentas.crearGraficaPastel();
            pieChart.setAnimated(false);

            LineChart<String, Number> lineChart = graficaVentas.crearGraficaLineas();
            lineChart.setAnimated(false);

            // Capturar gráficas de productos vendidos
            byte[] imgBarras = capturarGrafica(barChart);
            byte[] imgPastel = capturarGrafica(pieChart);
            byte[] imgLineas = capturarGrafica(lineChart);

            agregarGraficasCapturadas(document, imgBarras, imgPastel, imgLineas);
            agregarTablaDatos(document);

            // Crear y configurar gráficas de ventas diarias
            BarChart<String, Number> barChartVentas = ventasDiarias.crearGraficaBarras(true);
            barChartVentas.setAnimated(false);

            BarChart<String, Number> barChartOrdenes = ventasDiarias.crearGraficaBarras(false);
            barChartOrdenes.setAnimated(false);

            LineChart<String, Number> lineChartVentas = ventasDiarias.crearGraficaLineas();
            lineChartVentas.setAnimated(false);

            // Capturar gráficas de ventas diarias
            byte[] imgBarrasVentas = capturarGrafica(barChartVentas);
            byte[] imgBarrasOrdenes = capturarGrafica(barChartOrdenes);
            byte[] imgLineasVentas = capturarGrafica(lineChartVentas);

            agregarGraficasVentasDiarias(document, imgBarrasVentas, imgBarrasOrdenes, imgLineasVentas);
            agregarPiePagina(document);

            document.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            throw new IOException("Error al generar PDF: " + e.getMessage(), e);
        }
    }

    private void agregarResumenEjecutivo(Document document) {
        Paragraph tituloResumen = new Paragraph("RESUMEN EJECUTIVO")
                .setFontSize(16)
                .setMarginBottom(15);
        document.add(tituloResumen);

        // Resumen de productos vendidos
        float totalVentas = 0;
        int totalProductos = graficaVentas.getDatosVentas().size();
        String productoMasVendido = "";
        float mayorVenta = 0;

        for (VentaProductosDAO venta : graficaVentas.getDatosVentas()) {
            totalVentas += venta.getTotalVendido();
            if (venta.getTotalVendido() > mayorVenta) {
                mayorVenta = venta.getTotalVendido();
                productoMasVendido = venta.getProducto();
            }
        }

        float promedioVentas = totalProductos > 0 ? totalVentas / totalProductos : 0;

        // Resumen de ventas diarias
        double totalVentasDiarias = 0;
        int totalOrdenes = 0;
        String diaMayorVenta = "";
        double mayorVentaDia = 0;

        for (VentasDiariasDAO venta : ventasDiarias.getDatosVentas()) {
            totalVentasDiarias += venta.getTotal_ventas();
            totalOrdenes += venta.getTotal_ordenes();
            if (venta.getTotal_ventas() > mayorVentaDia) {
                mayorVentaDia = venta.getTotal_ventas();
                diaMayorVenta = venta.getDia().toString();
            }
        }

        double promedioVentasDiarias = ventasDiarias.getDatosVentas().size() > 0 ?
                totalVentasDiarias / ventasDiarias.getDatosVentas().size() : 0;

        // Formatear números
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);

        // Sección de productos
        document.add(new Paragraph("Productos Vendidos:")
                .setFontSize(14)
                .setMarginBottom(5));
        document.add(new Paragraph("• Total de productos analizados: " + totalProductos));
        document.add(new Paragraph("• Producto más vendido: " + productoMasVendido + " (" + mayorVenta + " unidades)"));
        document.add(new Paragraph("• Total de unidades vendidas: " + String.format("%.0f", totalVentas)));
        document.add(new Paragraph("• Promedio de ventas por producto: " + String.format("%.2f", promedioVentas)));

        document.add(new Paragraph().setMarginBottom(15));

        // Sección de ventas diarias
        document.add(new Paragraph("Ventas Diarias:")
                .setFontSize(14)
                .setMarginBottom(5));
        document.add(new Paragraph("• Total de ventas: " + currencyFormat.format(totalVentasDiarias)));
        document.add(new Paragraph("• Total de órdenes: " + numberFormat.format(totalOrdenes)));
        document.add(new Paragraph("• Día con mayor venta: " + diaMayorVenta + " (" + currencyFormat.format(mayorVentaDia) + ")"));
        document.add(new Paragraph("• Promedio diario de ventas: " + currencyFormat.format(promedioVentasDiarias)));

        document.add(new Paragraph().setMarginBottom(30));
    }

    private void agregarMejorEmpleado(Document document) {
        MejorEmpleadoDAO empleado = new MejorEmpleadoDAO();
        empleado = empleado.SELECT();

        Paragraph titulo = new Paragraph("MEJOR EMPLEADO DEL MES")
                .setFontSize(16)
                .setMarginBottom(15);
        document.add(titulo);

        // Crear tabla para la información del empleado
        Table tablaEmpleado = new Table(UnitValue.createPercentArray(new float[]{1, 2}));
        tablaEmpleado.setWidth(UnitValue.createPercentValue(80));
        tablaEmpleado.setMarginBottom(20);

        // Formatear fechas y números
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);

        // Agregar información básica
        tablaEmpleado.addCell(crearCeldaEncabezado("Nombre:"));
        tablaEmpleado.addCell(crearCeldaDato(empleado.getEmpleado()));

        tablaEmpleado.addCell(crearCeldaEncabezado("Puesto:"));
        tablaEmpleado.addCell(crearCeldaDato(empleado.getPuesto()));

        tablaEmpleado.addCell(crearCeldaEncabezado("ID Empleado:"));
        tablaEmpleado.addCell(crearCeldaDato(String.valueOf(empleado.getId())));

        tablaEmpleado.addCell(crearCeldaEncabezado("Última venta:"));
        tablaEmpleado.addCell(crearCeldaDato(sdf.format(empleado.getUltima_venta())));

        document.add(tablaEmpleado);

        // Agregar métricas del empleado
        Paragraph subtitulo = new Paragraph("MÉTRICAS DE DESEMPEÑO")
                .setFontSize(14)
                .setMarginBottom(10);
        document.add(subtitulo);

        Table tablaMetricas = new Table(UnitValue.createPercentArray(new float[]{1, 1, 1, 1}));
        tablaMetricas.setWidth(UnitValue.createPercentValue(100));
        tablaMetricas.setMarginBottom(30);

        tablaMetricas.addCell(crearCeldaMetrica("Ventas Totales", currencyFormat.format(empleado.getTotal_vendido())));
        tablaMetricas.addCell(crearCeldaMetrica("Órdenes Realizadas", numberFormat.format(empleado.getOrdenes_realizadas())));
        tablaMetricas.addCell(crearCeldaMetrica("Promedio por Orden", currencyFormat.format(empleado.getPromedio_por_orden())));
        tablaMetricas.addCell(crearCeldaMetrica("Eficiencia", calcularEficiencia(empleado)));

        document.add(tablaMetricas);
    }

    private Cell crearCeldaEncabezado(String texto) {
        return new Cell().add(new Paragraph(texto))
                .setFontSize(12)
                .setPadding(5);
    }

    private Cell crearCeldaDato(String texto) {
        return new Cell().add(new Paragraph(texto))
                .setFontSize(12)
                .setPadding(5);
    }

    private Cell crearCeldaMetrica(String titulo, String valor) {
        return new Cell()
                .add(new Paragraph(titulo).setMarginBottom(5))
                .add(new Paragraph(valor))
                .setTextAlignment(TextAlignment.CENTER)
                .setPadding(10)
                .setBorder(new SolidBorder(1));
    }

    private String calcularEficiencia(MejorEmpleadoDAO empleado) {
        double eficiencia = (empleado.getPromedio_por_orden() / 150) * 100;
        return String.format("%.1f%%", Math.min(eficiencia, 100));
    }

    private void agregarPortada(Document document) {
        Paragraph titulo = new Paragraph("REPORTE DE ANÁLISIS DE VENTAS")
                .setFontSize(24)
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(20);
        document.add(titulo);

        Paragraph subtitulo = new Paragraph("Análisis Completo de Ventas y Desempeño")
                .setFontSize(18)
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(30);
        document.add(subtitulo);

        String fechaHora = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        Paragraph fecha = new Paragraph("Generado el: " + fechaHora)
                .setFontSize(12)
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(50);
        document.add(fecha);

        document.add(new Paragraph().setMarginBottom(20));
    }

    private void configurarDocumento(Document document) {
        document.setMargins(36, 36, 36, 36); // 0.5 pulgadas
        document.getPdfDocument().setDefaultPageSize(PageSize.LETTER);
    }

    private byte[] capturarGrafica(Chart chart) throws Exception {
        final int anchoGrafica = 800;
        final int altoGrafica = 600;
        final byte[][] imageBytesHolder = new byte[1][1];
        final Exception[] exceptionHolder = new Exception[1];
        final CountDownLatch latch = new CountDownLatch(1);

        Platform.runLater(() -> {
            try {
                // Configuración de escena temporal
                StackPane tempContainer = new StackPane(chart);
                Scene tempScene = new Scene(tempContainer, anchoGrafica, altoGrafica);

                // Preservar estilos
                if (chart.getScene() != null) {
                    tempScene.getStylesheets().addAll(chart.getScene().getStylesheets());
                }

                // Configurar tamaño
                chart.setMinSize(anchoGrafica, altoGrafica);
                chart.setPrefSize(anchoGrafica, altoGrafica);

                // Forzar renderizado
                tempContainer.applyCss();
                tempContainer.layout();

                // Captura de alta calidad
                SnapshotParameters params = new SnapshotParameters();
                params.setTransform(Transform.scale(1.5, 1.5));
                WritableImage writableImage = new WritableImage(
                        (int)(anchoGrafica * 1.5),
                        (int)(altoGrafica * 1.5)
                );

                chart.snapshot(params, writableImage);
                BufferedImage bufferedImage = SwingFXUtils.fromFXImage(writableImage, null);

                // Guardar en memoria
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ImageIO.write(bufferedImage, "png", baos);
                imageBytesHolder[0] = baos.toByteArray();
                baos.close();

                // Depuración
                if (DEBUG_MODE) {
                    File debugFile = new File("debug_chart_" + System.currentTimeMillis() + ".png");
                    ImageIO.write(bufferedImage, "png", debugFile);
                    System.out.println("DEBUG: Gráfica guardada en " + debugFile.getAbsolutePath());
                }
            } catch (Exception e) {
                exceptionHolder[0] = e;
            } finally {
                latch.countDown();
            }
        });

        latch.await();

        if (exceptionHolder[0] != null) {
            throw new Exception("Error al capturar gráfica", exceptionHolder[0]);
        }
        if (imageBytesHolder[0] == null || imageBytesHolder[0].length == 0) {
            throw new Exception("La captura no produjo datos");
        }

        return imageBytesHolder[0];
    }

    private void agregarGraficasCapturadas(Document document, byte[] imgBarras, byte[] imgPastel, byte[] imgLineas)
            throws IOException {
        try {
            Paragraph tituloGraficas = new Paragraph("ANÁLISIS GRÁFICO DE PRODUCTOS VENDIDOS")
                    .setFontSize(16)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginBottom(20);
            document.add(tituloGraficas);

            // Gráfica de Barras
            if (imgBarras != null) {
                agregarSeccionGrafica(document,
                        "Gráfica de Barras - Comparación de Ventas por Producto",
                        imgBarras,
                        "Comparación directa entre cantidades vendidas por producto");
            }

            // Salto de página inteligente
            if (document.getPdfDocument().getNumberOfPages() > 0) {
                document.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
            }

            // Gráfica de Pastel
            if (imgPastel != null) {
                agregarSeccionGrafica(document,
                        "Gráfica de Pastel - Distribución de Ventas por Producto",
                        imgPastel,
                        "Proporción de ventas por producto respecto al total");
            }

            // Gráfica de Líneas
            if (imgLineas != null) {
                // Verificar espacio antes de agregar
                float espacioRestante = document.getPdfDocument()
                        .getLastPage()
                        .getPageSize()
                        .getHeight() - document.getRenderer().getCurrentArea().getBBox().getHeight();

                if (espacioRestante < 300) {
                    document.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
                }

                agregarSeccionGrafica(document,
                        "Gráfica de Líneas - Tendencia de Ventas por Producto",
                        imgLineas,
                        "Tendencia y patrón histórico de ventas por producto");
            }
        } catch (Exception e) {
            document.add(new Paragraph("Error al procesar gráficas: " + e.getMessage())
                    .setFontColor(ColorConstants.RED));
            throw new IOException("Error al agregar gráficas", e);
        }
    }

    private void agregarGraficasVentasDiarias(Document document, byte[] imgBarrasVentas, byte[] imgBarrasOrdenes, byte[] imgLineas)
            throws IOException {
        try {
            document.add(new AreaBreak(AreaBreakType.NEXT_PAGE));

            Paragraph tituloGraficas = new Paragraph("ANÁLISIS GRÁFICO DE VENTAS DIARIAS")
                    .setFontSize(16)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginBottom(20);
            document.add(tituloGraficas);

            // Gráfica de Barras (Ventas)
            if (imgBarrasVentas != null) {
                agregarSeccionGrafica(document,
                        "Gráfica de Barras - Ventas Totales por Día",
                        imgBarrasVentas,
                        "Comparación de ventas totales en términos monetarios por día");
            }

            // Salto de página inteligente
            if (document.getPdfDocument().getNumberOfPages() > 0) {
                document.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
            }

            // Gráfica de Barras (Órdenes)
            if (imgBarrasOrdenes != null) {
                agregarSeccionGrafica(document,
                        "Gráfica de Barras - Órdenes por Día",
                        imgBarrasOrdenes,
                        "Comparación del número de órdenes realizadas por día");
            }

            // Gráfica de Líneas
            if (imgLineas != null) {
                // Verificar espacio antes de agregar
                float espacioRestante = document.getPdfDocument()
                        .getLastPage()
                        .getPageSize()
                        .getHeight() - document.getRenderer().getCurrentArea().getBBox().getHeight();

                if (espacioRestante < 300) {
                    document.add(new AreaBreak(AreaBreakType.NEXT_PAGE));
                }

                agregarSeccionGrafica(document,
                        "Gráfica de Líneas - Tendencia de Ventas Diarias",
                        imgLineas,
                        "Tendencia comparativa entre ventas totales y número de órdenes por día");
            }
        } catch (Exception e) {
            document.add(new Paragraph("Error al procesar gráficas de ventas diarias: " + e.getMessage())
                    .setFontColor(ColorConstants.RED));
            throw new IOException("Error al agregar gráficas de ventas diarias", e);
        }
    }

    private void agregarSeccionGrafica(Document document, String titulo,
                                       byte[] imagenBytes, String descripcion) throws IOException {
        try {
            // Título
            document.add(new Paragraph(titulo)
                    .setFontSize(14)
                    .setMarginBottom(10));

            // Imagen
            ImageData imageData = ImageDataFactory.create(imagenBytes);
            Image imagen = new Image(imageData)
                    .setWidth(UnitValue.createPercentValue(90))
                    .setAutoScaleHeight(true)
                    .setHorizontalAlignment(HorizontalAlignment.CENTER)
                    .setMarginBottom(15);
            document.add(imagen);

            // Descripción
            document.add(new Paragraph(descripcion)
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.JUSTIFIED)
                    .setMarginBottom(20));
        } catch (Exception e) {
            throw new IOException("Error al agregar sección gráfica: " + titulo, e);
        }
    }

    private void agregarTablaDatos(Document document) {
        document.add(new AreaBreak());

        Paragraph tituloTabla = new Paragraph("DATOS DETALLADOS DE PRODUCTOS VENDIDOS")
                .setFontSize(16)
                .setMarginBottom(15);
        document.add(tituloTabla);

        Table table = new Table(UnitValue.createPercentArray(new float[]{3, 2}));
        table.setWidth(UnitValue.createPercentValue(100));

        table.addHeaderCell(new Cell().add(new Paragraph("Producto")));
        table.addHeaderCell(new Cell().add(new Paragraph("Cantidad Vendida")));

        for (VentaProductosDAO venta : graficaVentas.getDatosVentas()) {
            table.addCell(new Cell().add(new Paragraph(venta.getProducto())));
            table.addCell(new Cell().add(new Paragraph(String.format("%.0f", venta.getTotalVendido()))));
        }

        document.add(table);
    }

    private void agregarPiePagina(Document document) {
        document.add(new Paragraph().setMarginTop(30));
        Paragraph pie = new Paragraph("Reporte generado automáticamente por el Sistema de Gestión de Restaurante")
                .setFontSize(8)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(ColorConstants.GRAY);
        document.add(pie);
    }

    public void generarPDFConDialogo(Stage parentStage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Guardar Reporte PDF");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF", "*.pdf"));

        File file = fileChooser.showSaveDialog(parentStage);
        if (file != null) {
            // Asegura que la extensión sea .pdf
            String path = file.getAbsolutePath();
            if (!path.endsWith(".pdf")) path += ".pdf";

            // Ejecuta en un hilo separado para no bloquear la UI
            String finalPath = path;
            new Thread(() -> {
                try {
                    boolean exito = generarPDFCompleto(finalPath);

                    Platform.runLater(() -> {
                        if (exito) {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Éxito");
                            alert.setContentText("PDF guardado en: " + finalPath);
                            alert.showAndWait();
                        } else {
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("Error");
                            alert.setContentText("No se pudo guardar el PDF");
                            alert.showAndWait();
                        }
                    });
                } catch (Exception e) {
                    Platform.runLater(() -> {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error crítico");
                        alert.setContentText("Error al generar PDF: " + e.getMessage());
                        alert.showAndWait();
                    });
                    e.printStackTrace();
                }
            }).start();
        }
    }
}