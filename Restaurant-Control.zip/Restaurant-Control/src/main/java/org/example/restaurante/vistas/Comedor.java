package org.example.restaurante.vistas;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.example.restaurante.modelos.GenerarTicket;
import org.example.restaurante.modelosEntidad.CuentaDAO;
import org.example.restaurante.modelosEntidad.DetalleOrdenDAO;
import org.example.restaurante.vistas.registro.MetodoPago;
import org.example.restaurante.vistas.registro.RegistroOrden;

import java.util.stream.Collectors;

public class Comedor extends Stage {
    private VBox vRight, vCuentas;
    private HBox hBody, hMenu;
    private Button btnAbrirCuenta, btnCapturar, btnEditar, btnImprimir, btnPagar;
    private Scene scene;
    private CuentaDAO cSelec;
    private TableView<DetalleOrdenDAO> tbvDetalleOrden;
    private ObservableList<DetalleOrdenDAO> listOrden;

    public Comedor() {
        crearUI();
        this.setTitle("Comedor");
        this.setMaximized(true);
        this.setScene(scene);
        this.show();
    }

    public void crearMenu(){
        btnAbrirCuenta = btnMenu("Abrir Cuenta", "/iconos/iconoAbrirCuenta.png");
        btnAbrirCuenta.setId("btnAbrir");
        btnAbrirCuenta.setOnAction(e -> new RegistroOrden(null));
        btnCapturar = btnMenu("Capturar", "/iconos/iconoCapturar.png");
        btnCapturar.setOnAction(e -> capturar());
        btnEditar = btnMenu("Editar", "/iconos/iconoEditarCuenta.png");
        btnImprimir = btnMenu("Imprimir", "/iconos/iconoImprimir.png");
        btnImprimir.setOnAction(e -> new GenerarTicket(getCSelec()));
        btnPagar = btnMenu("Pagar", "/iconos/iconoPagar.png");
        btnPagar.setOnAction(e -> new MetodoPago(getCSelec()));

        HBox hSubMenu = new HBox(btnCapturar, btnEditar, btnImprimir, btnPagar);
        hSubMenu.getStyleClass().add("subMenu");

        hMenu = new HBox(btnAbrirCuenta, hSubMenu);
        hMenu.setSpacing(40);
        hMenu.getStyleClass().add("hMenu");
    }

    public void crearTablaDetalle(){
        tbvDetalleOrden = new TableView<>();

        TableColumn<DetalleOrdenDAO, String> colProducto = new TableColumn<>("Producto");
        colProducto.setCellValueFactory(celda -> new SimpleStringProperty(celda.getValue().getProducto().getNombre()));

        TableColumn<DetalleOrdenDAO, Integer> colCantidad = new TableColumn<>("Cantidad");
        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));

        TableColumn<DetalleOrdenDAO, Double> colPrecio = new TableColumn<>("Precio Unitario");
        colPrecio.setCellValueFactory(celda -> new SimpleDoubleProperty(celda.getValue().getProducto().getPrecio()).asObject());

        TableColumn<DetalleOrdenDAO, Double> colSubtotal = new TableColumn<>("Subtotal");
        colSubtotal.setCellValueFactory(celda -> {
            int cantidad = celda.getValue().getCantidad();
            double precio = celda.getValue().getProducto().getPrecio();
            return new SimpleDoubleProperty(cantidad * precio).asObject();
        });

        tbvDetalleOrden.getColumns().addAll(colProducto, colCantidad, colPrecio, colSubtotal);
        tbvDetalleOrden.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    public void crearUI() {
        Text tCuenta = new Text("Cuentas");
        tCuenta.setId("tCuenta");
        vCuentas = new VBox(tCuenta);
        vCuentas.getStyleClass().add("vCuentas");
        mostrarCuentasAbiertas();

        crearMenu();
        crearTablaDetalle();
        vRight = new VBox(hMenu, tbvDetalleOrden);
        vRight.getStyleClass().add("vRight");
        HBox.setHgrow(vRight, javafx.scene.layout.Priority.ALWAYS);

        hBody = new HBox(vCuentas, vRight);
        scene = new Scene(hBody);
        scene.getStylesheets().add(getClass().getResource("/styles/comedorStyle.css").toString());
    }

    public void agregarProductos(ObservableList<DetalleOrdenDAO> listNuevos){
        abrirDetalle();
        for (DetalleOrdenDAO objN : listNuevos) {
            boolean encontrado = false;

            for (DetalleOrdenDAO obj : listOrden) {
                if (objN.getIdProducto() == obj.getIdProducto()) {
                    obj.setCantidad(obj.getCantidad() + objN.getCantidad());
                    obj.UPDATE();
                    encontrado = true;
                    break;
                }
            }

            if (!encontrado) {
                listOrden.add(objN);
                objN.INSERT();
            }
        }

    }

    private void mostrarCuentasAbiertas() {
        vCuentas.getChildren().clear();

        var cuentas = new CuentaDAO().SELECT().stream()
                .filter(cuenta -> !cuenta.isCerrada())
                .collect(Collectors.toList());

        for (CuentaDAO cuenta : cuentas) {
            Button btnCuenta = new Button(
                    "Cuenta #" + cuenta.getIdCuenta() +
                            "\n"+ cuenta.getOrden().getMesa().getNombre());
            btnCuenta.setStyle("-fx-font-size: 16px; -fx-padding: 20px;");
            btnCuenta.setPrefSize(200, 100);
            btnCuenta.setOnAction(e -> {
                cSelec = cuenta;
                abrirDetalle();
            });

            vCuentas.getChildren().add(btnCuenta);
        }
    }

    public void llenarListaOrden(){
        int idOrden = cSelec.getIdOrden();
        DetalleOrdenDAO detalleOrden = new DetalleOrdenDAO();
        listOrden = detalleOrden.selectOrden(idOrden);
    }

    private Button btnMenu(String name, String url){
        ImageView imv = new ImageView(getClass().getResource(url).toString());
        imv.setFitHeight(50);
        imv.setFitWidth(50);

        Button btn = new Button(name, imv);
        btn.getStyleClass().add("btnMenu");

        return btn;
    }

    public void abrirDetalle() {
        llenarListaOrden();
        tbvDetalleOrden.setItems(listOrden);
    }

    public void capturar(){
        if(cSelec != null){
            listOrden.clear();
            new Capturar(this);
        }
    }

    public CuentaDAO getCSelec(){
        return cSelec;
    }
}
