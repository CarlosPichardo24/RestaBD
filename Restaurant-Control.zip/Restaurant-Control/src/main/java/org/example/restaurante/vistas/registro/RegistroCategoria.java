package org.example.restaurante.vistas.registro;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.example.restaurante.componentes.TxtRegistro;
import org.example.restaurante.modelos.Registro;
import org.example.restaurante.modelosEntidad.CategoriaDAO;

public class RegistroCategoria extends Stage implements Registro<CategoriaDAO>{
    private Text title;
    private TxtRegistro txtNombre, txtDescripcion;
    private Button btnGuardar;
    private VBox vbox;
    private Scene scene;
    private CategoriaDAO obj;
    private TableView<CategoriaDAO> tbvCategoria;

    public void crearUI(){
        title = new Text("Categoria");
        title.getStyleClass().add("title");

        txtNombre = new TxtRegistro("Nombre Categoria", "txtField");

        txtDescripcion = new TxtRegistro("Descripcion Categoria", "txtField");

        btnGuardar = new Button("Guardar");
        btnGuardar.getStyleClass().add("btnGuardar");
        btnGuardar.setOnAction(e -> {
            obj.setNombre(txtNombre.getText());
            obj.setDescripcion(txtDescripcion.getText());

            if(obj.getIdCategoria() > 0)
                obj.UPDATE();
            else
                obj.INSERT();

            tbvCategoria.setItems(obj.SELECT());
            tbvCategoria.refresh();

            this.close();
        });

        vbox = new VBox(title, txtNombre, txtDescripcion, btnGuardar);
        vbox.getStyleClass().add("vboxBody");
        vbox.setPadding(new Insets(10, 10, 20, 10));
        vbox.setSpacing(10);
        vbox.setAlignment(Pos.TOP_CENTER);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/registroStyle.css").toString());
    }

    public void llenar(CategoriaDAO obj){
        this.obj = obj;

        txtNombre.setText(obj.getNombre());
        txtDescripcion.setText(obj.getDescripcion());

        this.show();
    }

    public RegistroCategoria(TableView<CategoriaDAO> tbvCategoria, boolean show) {
        this.tbvCategoria = tbvCategoria;
        obj = new CategoriaDAO();

        crearUI();

        this.setMinWidth(320);
        this.setTitle("Categoria");
        this.setScene(scene);

        if(show)
            this.show();
    }
}
