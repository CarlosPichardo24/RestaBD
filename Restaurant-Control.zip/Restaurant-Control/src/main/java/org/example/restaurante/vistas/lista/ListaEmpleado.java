package org.example.restaurante.vistas.lista;

import javafx.scene.Scene;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.restaurante.componentes.BotonAgregar;
import org.example.restaurante.componentes.TablaEntidad;
import org.example.restaurante.modelosEntidad.EmpleadoDAO;
import org.example.restaurante.vistas.registro.RegistroEmpleado;

public class ListaEmpleado extends Stage {
    private Scene scene;
    private VBox vbox;
    private TablaEntidad<EmpleadoDAO, RegistroEmpleado> tbeEmpleado;
    private EmpleadoDAO objEmpleado;
    private RegistroEmpleado rgEmpleado;
    private BotonAgregar btnAgregar;
    private ToolBar tlbMenu;

    public void crearUI(){
        tbeEmpleado = new TablaEntidad<>();

        objEmpleado = new EmpleadoDAO();
        rgEmpleado = new RegistroEmpleado(tbeEmpleado, false);

        tbeEmpleado.setColumna("Nombre", "nombre");
        tbeEmpleado.setColumna("Apellido", "apellido");
        tbeEmpleado.setColumna("CURP", "curp");
        tbeEmpleado.setColumna("RFC", "rfc");
        tbeEmpleado.setColumna("Sueldo", "sueldo");
        tbeEmpleado.setColumna("Puesto", "puesto");
        tbeEmpleado.setColumna("Teléfono", "telefono");
        tbeEmpleado.setColumna("Horario", "horario");
        tbeEmpleado.setColumna("Fecha Ingreso", "fechaIngreso");

        tbeEmpleado.crearTabla(objEmpleado, rgEmpleado);

        btnAgregar = new BotonAgregar();
        btnAgregar.setOnAction(e -> new RegistroEmpleado(tbeEmpleado, true));
        tlbMenu = new ToolBar(btnAgregar);

        vbox = new VBox(tlbMenu, tbeEmpleado);
        vbox.setId("vBody");

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/tableStyle.css").toString());
    }

    public ListaEmpleado() {
        crearUI();
        this.setTitle("Lista de empleados");
        this.setMaximized(true);
        this.setScene(scene);
        this.show();
    }
}
