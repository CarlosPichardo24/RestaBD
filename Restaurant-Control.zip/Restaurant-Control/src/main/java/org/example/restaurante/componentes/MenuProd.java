package org.example.restaurante.componentes;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.layout.VBox;
import org.example.restaurante.modelos.Conexion;
import org.example.restaurante.modelosEntidad.ProductoDAO;
import org.example.restaurante.vistas.Capturar;

import java.sql.ResultSet;
import java.sql.Statement;

public class MenuProd extends VBox {
    private int m;
    private FilaMenu inicio;
    private FilaMenu fin;
    private ProductoDAO prSelec;
    private Capturar cap;

    public String textLine(String str){
        if (str == null) return "";
        return str.replace(" ", "\n");
    }

    public MenuProd(int idCat, Capturar cap) {
        m = 6;
        fin = inicio = null;
        crearMenu(filtrar(idCat));
        this.cap = cap;
    }

    public void addItem(BtnMenu btn){
        if(inicio == null){
            fin = inicio = new FilaMenu(m);
            this.getChildren().add(inicio);
        }
        if(!fin.addBtn(btn)){
            FilaMenu temp = new FilaMenu(m);
            fin.sig = temp;
            fin = temp;
            this.getChildren().add(fin);
            fin.addBtn(btn);
        }
    }

    public void crearMenu(ObservableList<ProductoDAO> list){
        this.getChildren().clear();

        for (ProductoDAO prod : list) {
            BtnMenu<ProductoDAO> btn = new BtnMenu("btnProd", prod);
            btn.setText(textLine(prod.getNombre()));
            btn.setOnAction(e -> {
                prSelec = btn.getObj();
                cap.agregarProd();
            });
            addItem(btn);
        }
    }

    public ProductoDAO getPrSelec(){
        return prSelec;
    }

    public ObservableList<ProductoDAO> filtrar(int id) {
        ObservableList<ProductoDAO> productos = FXCollections.observableArrayList();
        String query = "SELECT * FROM producto WHERE idCategoria = "+id;
        ObservableList<ProductoDAO> list = FXCollections.observableArrayList();
        ProductoDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new ProductoDAO();

                obj.setIdProducto(res.getInt("idProducto"));
                obj.setNombre(res.getString("nombre"));
                obj.setPrecio(res.getDouble("precio"));
                obj.setIdCategoria(res.getInt("idCategoria"));

                productos.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return productos;
    }

}

