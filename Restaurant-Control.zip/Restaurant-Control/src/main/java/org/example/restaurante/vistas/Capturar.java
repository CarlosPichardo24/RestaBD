package org.example.restaurante.vistas;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.example.restaurante.componentes.MenuCat;
import org.example.restaurante.componentes.MenuProd;
import org.example.restaurante.modelos.Conexion;
import org.example.restaurante.modelosEntidad.CategoriaDAO;
import org.example.restaurante.modelosEntidad.CuentaDAO;
import org.example.restaurante.modelosEntidad.DetalleOrdenDAO;
import org.example.restaurante.modelosEntidad.ProductoDAO;

import java.util.Stack;

public class Capturar extends Stage {
    private Scene scene;
    private HBox hBody, hOpciones;
    private VBox vLeft, vRight, vMenuProd;
    private MenuCat mnCat;
    private CategoriaDAO objCat;
    private CuentaDAO objCuenta;
    private Comedor comedor;
    private MenuProd mnProd;
    private Text titleProd;
    private Stack<ProductoDAO> stack;
    private ObservableList<DetalleOrdenDAO> prComandados;
    private TableView<DetalleOrdenDAO> tbvDetalle;
    private Button btnDeshacer, btnCancelar, btnGuardar;

    public void actProd(){
        int idCat = mnCat.getCatSelec().getIdCategoria();

        titleProd.setText(mnCat.getCatSelec().getNombre());

        mnProd = new MenuProd(idCat, this);
        vMenuProd.getChildren().clear();
        vMenuProd.getChildren().add(mnProd);
    }

    public void agregarProd(){
        ProductoDAO prodSelec = mnProd.getPrSelec();
        if(!stack.contains(prodSelec)){
            DetalleOrdenDAO detalleOrden = new DetalleOrdenDAO();
            detalleOrden.setIdOrden(objCuenta.getIdOrden());
            detalleOrden.setIdProducto(mnProd.getPrSelec().getIdProducto());
            detalleOrden.setCantidad(1);

            prComandados.add(detalleOrden);
        }
        else{
            for(DetalleOrdenDAO d : prComandados){
                if(d.getIdProducto() == prodSelec.getIdProducto())
                    d.setCantidad(d.getCantidad() + 1);
            }
            tbvDetalle.refresh();
        }

        stack.push(prodSelec);
    }

    public void quitarProd(){
        DetalleOrdenDAO borrar = null;
        if(!stack.empty()){
            ProductoDAO prod = stack.pop();
            for(DetalleOrdenDAO d : prComandados){
                if(d.getIdProducto() == prod.getIdProducto())
                    d.setCantidad(d.getCantidad() - 1);
                if(d.getCantidad() == 0)
                    borrar = d;
            }
            if(borrar != null) prComandados.remove(borrar);
            tbvDetalle.refresh();
        }
    }

    public Button btnOpcion(String text, String color){
        Button btn = new Button(text);
        btn.getStyleClass().add("btnOpcion");
        btn.setStyle("-fx-background-color: #" + color + ";");
        return btn;
    }

    public void mnOpciones(){
        btnDeshacer = btnOpcion("Deshacer", "ef6c34");
        btnDeshacer.setOnAction(e -> quitarProd());
        btnCancelar = btnOpcion("Cancelar", "da2020");
        btnCancelar.setOnAction(e -> this.close());
        btnGuardar = btnOpcion("Guardar","eae684");
        btnGuardar.setOnAction(e -> {
            comedor.agregarProductos(prComandados);
            this.close();
        });

        hOpciones = new HBox(btnDeshacer, btnCancelar, btnGuardar);
    }

    public void crearTabla(){
        tbvDetalle = new TableView<>();
        TableColumn<DetalleOrdenDAO, Integer> colCantidad = new TableColumn<>("CANT.");
        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        TableColumn<DetalleOrdenDAO, String> colNombre = new TableColumn<>("PRODUCTO");
        colNombre.setCellValueFactory(celda -> new SimpleStringProperty(celda.getValue().getProducto().getNombre()));
        TableColumn<DetalleOrdenDAO, Double> colImporte = new TableColumn<>("IMPORTE");
        colImporte.setCellValueFactory(celda -> new SimpleDoubleProperty(celda.getValue().getProducto().getPrecio()).asObject());

        tbvDetalle.getColumns().addAll(colCantidad, colNombre, colImporte);
        tbvDetalle.setItems(prComandados);
        tbvDetalle.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    public void crearUI(){
        mnCat = new MenuCat(this);
        mnCat.getStyleClass().add("mnCat");

        mnOpciones();

        crearTabla();
        vLeft = new VBox(hOpciones, tbvDetalle);
        vLeft.getStyleClass().add("vLeft");

        vMenuProd = new VBox();
        vMenuProd.getStyleClass().add("vMenuProd");

        titleProd = new Text("Productos");
        titleProd.setId("ttProd");
        HBox hText = new HBox(titleProd);
        hText.setStyle("-fx-alignment: center; -fx-padding: 30 5 5 5;");
        vRight = new VBox(mnCat, hText, vMenuProd);
        vRight.getStyleClass().add("vRight");
        HBox.setHgrow(vRight, javafx.scene.layout.Priority.ALWAYS);
        hBody = new HBox(vLeft, vRight);

        scene = new Scene(hBody);
        scene.getStylesheets().add(getClass().getResource("/styles/capturaStyle.css").toString());
    }

    public Capturar(Comedor comedor) {
        this.comedor = comedor;
        objCuenta = comedor.getCSelec();
        stack = new Stack<>();
        prComandados = FXCollections.observableArrayList();
        crearUI();

        this.setTitle("Captura de productos");
        this.setMaximized(true);
        this.setScene(scene);
        this.show();
    }
}
