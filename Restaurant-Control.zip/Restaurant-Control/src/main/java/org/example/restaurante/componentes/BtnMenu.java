package org.example.restaurante.componentes;

import javafx.scene.control.Button;

public class BtnMenu<T> extends Button {
    private T obj;

    public BtnMenu(String style, T obj) {
        this.obj = obj;
        this.getStyleClass().add(style);
    }

    public T getObj() {
        return obj;
    }
}
