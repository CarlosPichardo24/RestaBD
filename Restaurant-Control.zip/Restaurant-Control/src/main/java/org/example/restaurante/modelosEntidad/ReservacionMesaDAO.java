package org.example.restaurante.modelosEntidad;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.restaurante.modelos.Conexion;

import java.sql.ResultSet;
import java.sql.Statement;

public class ReservacionMesaDAO {
    private int idReservacion;
    private int idMesa;
    private String comentarios;

    public void INSERT(){
        String query = "INSERT INTO reservacionMesa (idReservacion, idMesa, comentarios) " +
                "VALUES ("+idReservacion+", "+idMesa+", '"+comentarios+"')";
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void UPDATE(){
        String query = "UPDATE reservacionMesa SET " +
                "idReservacion = "+idReservacion+", " +
                "idMesa = "+idMesa+", " +
                "comentarios = '"+comentarios+"' " +
                "WHERE idReservacion = "+idReservacion+" AND idMesa = "+idMesa;

        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void DELETE(){
        String query = "DELETE FROM reservacionMesa WHERE idReservacion = "+idReservacion+"AND idMesa = "+idMesa;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ObservableList<ReservacionMesaDAO> SELECT(){
        String query = "SELECT * FROM reservacionMesa";
        ObservableList<ReservacionMesaDAO> list = FXCollections.observableArrayList();
        ReservacionMesaDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new ReservacionMesaDAO();

                obj.setIdReservacion(res.getInt("idReservacion"));
                obj.setIdMesa(res.getInt("idMesa"));
                obj.setComentarios(res.getString("comentarios"));

                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public int getIdReservacion() {
        return idReservacion;
    }

    public void setIdReservacion(int idReservacion) {
        this.idReservacion = idReservacion;
    }

    public int getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(int idMesa) {
        this.idMesa = idMesa;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }
}
