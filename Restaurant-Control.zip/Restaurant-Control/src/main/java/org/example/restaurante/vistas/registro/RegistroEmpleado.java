package org.example.restaurante.vistas.registro;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.example.restaurante.componentes.SelectFecha;
import org.example.restaurante.componentes.SelectHora;
import org.example.restaurante.componentes.TxtRegistro;
import org.example.restaurante.modelos.Registro;
import org.example.restaurante.modelosEntidad.EmpleadoDAO;

public class RegistroEmpleado extends Stage implements Registro<EmpleadoDAO>{

    private Text title;
    private SelectFecha slFecha;
    private TxtRegistro txtNombre, txtApellido, txtCurp, txtRFC, txtSueldo, txtPuesto, txtTelefono, txtHorario;
    private Button btnGuardar;
    private VBox vbox;
    private Scene scene;
    private EmpleadoDAO obj;
    private TableView<EmpleadoDAO> tbvEmpleado;

    public void crearUI(){
        title = new Text("Empleado");
        title.getStyleClass().add("title");

        txtNombre = new TxtRegistro("Nombre Empleado", "txtField");

        txtApellido = new TxtRegistro("Apellido Empleado", "txtField");

        txtCurp = new TxtRegistro("Curp Empleado", "txtField");

        txtRFC = new TxtRegistro("RFC Empleado", "txtField");

        txtSueldo = new TxtRegistro("Sueldo Empleado", "txtField");

        txtPuesto = new TxtRegistro("Puesto Empleado", "txtField");

        txtTelefono = new TxtRegistro("Telefono Empleado", "txtField");

        txtHorario = new TxtRegistro("Horario Empleado", "txtField");

        slFecha = new SelectFecha("Fecha Ingreso");
        slFecha.getStyleClass().add("slFech");

        btnGuardar = new Button("Guardar");
        btnGuardar.getStyleClass().add("btnGuardar");
        btnGuardar.setOnAction( e -> {
            obj.setNombre(txtNombre.getText());
            obj.setApellido(txtApellido.getText());
            obj.setCurp(txtCurp.getText());
            obj.setRfc(txtRFC.getText());
            obj.setSueldo(Double.parseDouble(txtSueldo.getText()));
            obj.setPuesto(txtPuesto.getText());
            obj.setTelefono(txtTelefono.getText());
            obj.setHorario(txtHorario.getText());
            obj.setFechaIngreso(slFecha.getFecha());

            if(obj.getIdEmpleado() > 0)
                obj.UPDATE();
            else
                obj.INSERT();

            tbvEmpleado.setItems(obj.SELECT());
            tbvEmpleado.refresh();

            this.close();
        });

        vbox = new VBox(title, txtNombre, txtApellido, txtCurp, txtRFC, txtSueldo, txtPuesto, txtTelefono, txtHorario, slFecha, btnGuardar);
        vbox.getStyleClass().add("vboxBody");
        vbox.setPadding(new Insets(10, 10, 20, 10));
        vbox.setSpacing(10);
        vbox.setAlignment(Pos.TOP_CENTER);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/registroStyle.css").toString());
    }

    @Override
    public void llenar(EmpleadoDAO obj){
        this.obj = obj;

        txtNombre.setText(obj.getNombre());
        txtApellido.setText(obj.getApellido());
        txtCurp.setText(obj.getCurp());
        txtRFC.setText(obj.getRfc());
        txtSueldo.setText(Double.toString(obj.getSueldo()));
        txtPuesto.setText(obj.getPuesto());
        txtTelefono.setText(obj.getTelefono());
        txtHorario.setText(obj.getHorario());

        slFecha.setFechaCompleta(obj.getFechaIngreso());

        this.show();
    }

    public RegistroEmpleado(TableView<EmpleadoDAO> tbvEmpleado, boolean show){
        this.tbvEmpleado = tbvEmpleado;
        obj = new EmpleadoDAO();

        crearUI();

        this.setMinWidth(320);
        this.setTitle("Empleado");
        this.setScene(scene);

        if(show)
            this.show();
    }
}
