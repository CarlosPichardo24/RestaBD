package org.example.restaurante.vistas.registro;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.example.restaurante.componentes.SelectFecha;
import org.example.restaurante.componentes.SelectHora;
import org.example.restaurante.componentes.TxtRegistro;
import org.example.restaurante.modelos.Registro;
import org.example.restaurante.modelosEntidad.ClienteDAO;
import org.example.restaurante.modelosEntidad.InsumoDAO;
import org.example.restaurante.modelosEntidad.ProveedorDAO;
import org.example.restaurante.modelosEntidad.ReservacionDAO;

public class RegistroReservacion extends Stage implements Registro<ReservacionDAO> {
    private Text title;
    private ComboBox<ClienteDAO> cmbCliente;
    private SelectFecha slFecha;
    private SelectHora slHora;
    private Button btnGuardar;
    private VBox vbox;
    private Scene scene;
    private ReservacionDAO obj;
    private TableView<ReservacionDAO> tbvReservacion;

    public void crearUI(){
        title = new Text("Reservacion");
        title.getStyleClass().add("title");

        ClienteDAO objCliente = new ClienteDAO();
        cmbCliente = new ComboBox<>();
        cmbCliente.setItems(objCliente.SELECT());

        slFecha = new SelectFecha("Fecha Reservacion");
        slHora = new SelectHora("Hora Reservacion");

        btnGuardar = new Button("Guardar");
        btnGuardar.getStyleClass().add("btnGuardar");
        btnGuardar.setOnAction(e -> {
            obj.setIdCliente(cmbCliente.getValue().getIdCliente());
            obj.setFechaReservacion(slFecha.getFecha());
            obj.setHoraReservacion(slHora.getHoraCompleta());

            if(obj.getIdReservacion() > 0)
                obj.UPDATE();
            else
                obj.INSERT();

            tbvReservacion.setItems(obj.SELECT());
            tbvReservacion.refresh();

            this.close();
        });

        vbox = new VBox(title, cmbCliente, slFecha, slHora, btnGuardar);
        vbox.getStyleClass().add("vboxBody");
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(10, 10, 20, 10));
        vbox.setAlignment(Pos.TOP_CENTER);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/registroStyle.css").toString());

    }

    public void llenar(ReservacionDAO obj){
        this.obj = obj;

        ClienteDAO cliente = new ClienteDAO();


        for (ClienteDAO c : cliente.SELECT()) {
            if (c.getIdCliente() == obj.getIdCliente()) {
                cliente = c;
                break;
            }
        }

        cmbCliente.setValue(cliente);
        slFecha.setFechaCompleta(obj.getFechaReservacion());
        slHora.setHoraCompleta(obj.getHoraReservacion());
        this.show();
    }

    public RegistroReservacion(TableView<ReservacionDAO> tbvReservacion, boolean show){
        this.tbvReservacion = tbvReservacion;
        obj = new ReservacionDAO();

        crearUI();

        this.setMinWidth(320);
        this.setTitle("Registro Reservacion");
        this.setScene(scene);

        if(show)
            this.show();
    }
}
