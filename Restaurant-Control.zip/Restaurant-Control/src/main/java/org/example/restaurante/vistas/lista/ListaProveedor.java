package org.example.restaurante.vistas.lista;

import javafx.scene.Scene;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.restaurante.componentes.BotonAgregar;
import org.example.restaurante.componentes.TablaEntidad;
import org.example.restaurante.modelosEntidad.ProveedorDAO;
import org.example.restaurante.vistas.registro.RegistroProveedor;

public class ListaProveedor extends Stage {

    private TablaEntidad<ProveedorDAO, RegistroProveedor> tbeProveedor;
    private ProveedorDAO objProveedor;
    private RegistroProveedor rgProveedor;
    private BotonAgregar btnAgregar;
    private ToolBar tlbMenu;
    private VBox vbox;
    private Scene scene;

    public void crearUI(){
        tbeProveedor = new TablaEntidad<>();
        objProveedor = new ProveedorDAO();

        tbeProveedor.setColumna("Nombre", "nombre");
        tbeProveedor.setColumna("Telefono", "telefono");
        tbeProveedor.setColumna("Direccion", "direccion");
        tbeProveedor.setColumna("Correo", "email");

        rgProveedor = new RegistroProveedor(tbeProveedor, false);
        tbeProveedor.crearTabla(objProveedor, rgProveedor);

        btnAgregar = new BotonAgregar();
        btnAgregar.setOnAction(e -> new RegistroProveedor(tbeProveedor, true));

        tlbMenu = new ToolBar(btnAgregar);

        vbox = new VBox(tlbMenu, tbeProveedor);
        vbox.getStyleClass().add("vBody");

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/tableStyle.css").toString());
    }

    public ListaProveedor() {
        crearUI();
        this.setTitle("Lista de proveedores");
        this.setMaximized(true);
        this.setScene(scene);
        this.show();
    }
}
