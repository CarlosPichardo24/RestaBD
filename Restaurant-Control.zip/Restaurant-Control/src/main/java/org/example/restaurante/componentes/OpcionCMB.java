package org.example.restaurante.componentes;

public class OpcionCMB {

    private int id;
    private String txt;

    public OpcionCMB(int id, String txt) {
        this.id = id;
        this.txt = txt;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return txt;
    }
}
