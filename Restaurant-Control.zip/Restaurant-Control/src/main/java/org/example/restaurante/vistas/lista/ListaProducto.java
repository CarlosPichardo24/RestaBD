package org.example.restaurante.vistas.lista;

import javafx.scene.Scene;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.restaurante.componentes.BotonAgregar;
import org.example.restaurante.componentes.TablaEntidad;
import org.example.restaurante.modelosEntidad.ProductoDAO;
import org.example.restaurante.vistas.registro.RegistroProducto;

public class ListaProducto extends Stage {
    private TablaEntidad<ProductoDAO, RegistroProducto> tbeProducto;
    private ProductoDAO objProducto;
    private RegistroProducto rgProducto;
    private VBox vbox;
    private ToolBar tlbMenu;
    private BotonAgregar btnAgregar;
    private Scene scene;

    public void crearUI(){
        tbeProducto = new TablaEntidad<>();
        objProducto = new ProductoDAO();

        tbeProducto.setColumna("Nombre", "nombre");
        tbeProducto.setColumna("Precio", "precio");
        tbeProducto.setColumna("Categoría", "nomCategoria");

        rgProducto = new RegistroProducto(tbeProducto, false);

        tbeProducto.crearTabla(objProducto, rgProducto);

        btnAgregar = new BotonAgregar();
        btnAgregar.setOnAction(e -> new RegistroProducto(tbeProducto, true));

        tlbMenu = new ToolBar(btnAgregar);

        vbox = new VBox(tlbMenu, tbeProducto);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/tableStyle.css").toString());
    }

    public ListaProducto() {
        crearUI();
        this.setTitle("Lista de Productos");
        this.setMaximized(true);
        this.setScene(scene);
        this.show();
    }
}
