package org.example.restaurante.componentes;

import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.example.restaurante.modelos.Nombrable;

public class MenuTouch<T extends Nombrable> extends Stage {
    private int m;
    private VBox vMenu;
    private FilaMenu inicio;
    private FilaMenu fin;
    private Scene scene;
    private T objSeleccionado = null;

    public void crearUI(){
        vMenu = new VBox();
        scene = new Scene(vMenu);
        scene.getStylesheets().add(getClass().getResource("/styles/touchStyle.css").toString());
    }

    public MenuTouch(ObservableList<T> list, String title) {
        m = 4;
        fin = inicio = null;

        crearUI();
        crearMenu(list);

        this.setTitle(title);
        this.setScene(scene);
        this.setMinWidth(800);
        this.setMinHeight(140);
        this.initModality(Modality.APPLICATION_MODAL);
    }

    public void addItem(BtnMenu btn){
        if(inicio == null){
            fin = inicio = new FilaMenu(m);
            vMenu.getChildren().add(inicio);
        }
        if(!fin.addBtn(btn)){
            FilaMenu temp = new FilaMenu(m);
            fin.sig = temp;
            fin = temp;
            vMenu.getChildren().add(fin);
            fin.addBtn(btn);
        }
    }

    public void crearMenu(ObservableList<T> list){
        for (T obj : list) {
            BtnMenu<T> btn = new BtnMenu("btnTouch", obj);
            btn.setText(obj.getNombre());
            btn.setOnAction(e -> {
                    objSeleccionado = btn.getObj();
                    this.close();
            });
            addItem(btn);
        }
    }

    public T getObjSeleccionado() {
        return objSeleccionado;
    }

}

