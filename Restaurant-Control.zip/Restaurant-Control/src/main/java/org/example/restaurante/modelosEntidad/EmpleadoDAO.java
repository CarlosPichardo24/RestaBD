package org.example.restaurante.modelosEntidad;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.restaurante.modelos.Conexion;
import org.example.restaurante.modelos.Entidad;
import org.example.restaurante.modelos.Nombrable;

import java.sql.ResultSet;
import java.sql.Statement;

public class EmpleadoDAO implements Entidad<EmpleadoDAO>, Nombrable {
    private int idEmpleado;
    private String nombre;
    private String apellido;
    private String curp;
    private String rfc;
    private double sueldo;
    private String puesto;
    private String telefono;
    private String horario;
    private String fechaIngreso;

    public void INSERT(){
        String query = "INSERT INTO empleado (nombre, apellido, curp, rfc, sueldo, puesto, telefono, horario, fechaIngreso)" +
                "values ('"+nombre+"', '"+apellido+"','"+curp+"','"+rfc+"',"+sueldo+",'"+puesto+"','"+telefono+"','"+horario+"','"+fechaIngreso+"')";
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void UPDATE(){
        String query = "UPDATE empleado SET " +
                "nombre = '"+nombre+"', " +
                "apellido = '"+apellido+"', " +
                "curp = '"+curp+"', " +
                "rfc = '"+rfc+"', " +
                "sueldo = "+sueldo+", " +
                "puesto = '"+puesto+"', " +
                "telefono = '"+telefono+"', " +
                "horario = '"+horario+"', " +
                "fechaIngreso = '"+fechaIngreso+"' " +
                "WHERE idEmpleado = "+idEmpleado;

        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void DELETE(){
        String query = "DELETE FROM empleado WHERE idEmpleado = "+idEmpleado;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public ObservableList<EmpleadoDAO> SELECT(){
        String query = "SELECT * FROM empleado";
        ObservableList<EmpleadoDAO> list = FXCollections.observableArrayList();
        EmpleadoDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new EmpleadoDAO();

                obj.setIdEmpleado(res.getInt("idEmpleado"));
                obj.setNombre(res.getString("nombre"));
                obj.setApellido(res.getString("apellido"));
                obj.setCurp(res.getString("curp"));
                obj.setRfc(res.getString("rfc"));
                obj.setSueldo(res.getDouble("sueldo"));
                obj.setPuesto(res.getString("puesto"));
                obj.setTelefono(res.getString("telefono"));
                obj.setHorario(res.getString("horario"));
                obj.setFechaIngreso(res.getString("fechaIngreso"));

                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public String toString(){
        return nombre;
    }


    public EmpleadoDAO SELECT_ADMIN(){
        String query = "SELECT * FROM empleado WHERE idEmpledado = 1";
        EmpleadoDAO obj = null;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            obj = new EmpleadoDAO();
            obj.setIdEmpleado(res.getInt("idEmpleado"));
            obj.setNombre(res.getString("nombre"));
            obj.setApellido(res.getString("apellido"));
            obj.setCurp(res.getString("curp"));
            obj.setRfc(res.getString("rfc"));
            obj.setSueldo(res.getDouble("sueldo"));
            obj.setPuesto(res.getString("puesto"));
            obj.setTelefono(res.getString("telefono"));
            obj.setHorario(res.getString("horario"));
            obj.setFechaIngreso(res.getString("fechaIngreso"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return obj;
    }


    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCurp() {
        return curp;
    }

    public void setCurp(String curp) {
        this.curp = curp;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }
}
