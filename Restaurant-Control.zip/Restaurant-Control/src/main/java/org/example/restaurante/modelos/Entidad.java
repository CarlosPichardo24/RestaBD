package org.example.restaurante.modelos;

import javafx.collections.ObservableList;

public interface Entidad<E> {
    void DELETE();
    ObservableList<E> SELECT();
}
