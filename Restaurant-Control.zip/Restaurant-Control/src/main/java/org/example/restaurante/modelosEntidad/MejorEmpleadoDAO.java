package org.example.restaurante.modelosEntidad;

import org.example.restaurante.modelos.Conexion;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;

public class MejorEmpleadoDAO {
    private String empleado, puesto;
    private float total_vendido, promedio_por_orden;
    private int ordenes_realizadas, id;
    private Date ultima_venta; // Cambiado a java.sql.Date

    // Getters y setters
    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public float getPromedio_por_orden() {
        return promedio_por_orden;
    }

    public void setPromedio_por_orden(float promedio_por_orden) {
        this.promedio_por_orden = promedio_por_orden;
    }

    public Date getUltima_venta() {
        return ultima_venta;
    }

    public void setUltima_venta(Date ultima_venta) {
        this.ultima_venta = ultima_venta;
    }

    public String getEmpleado() {
        return empleado;
    }

    public void setEmpleado(String empleado) {
        this.empleado = empleado;
    }

    public float getTotal_vendido() {
        return total_vendido;
    }

    public void setTotal_vendido(float total_vendido) {
        this.total_vendido = total_vendido;
    }

    public int getOrdenes_realizadas() {
        return ordenes_realizadas;
    }

    public void setOrdenes_realizadas(int ordenes_realizadas) {
        this.ordenes_realizadas = ordenes_realizadas;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public MejorEmpleadoDAO SELECT() {
        String query = "SELECT * FROM BESTEMPLOYEE";
        MejorEmpleadoDAO obj = null;
        try {
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            if (res.next()) {
                obj = new MejorEmpleadoDAO();
                obj.setId(res.getInt("id"));
                obj.setPuesto(res.getString("puesto"));
                obj.setEmpleado(res.getString("empleado"));
                obj.setOrdenes_realizadas(res.getInt("ordenes_realizadas"));
                obj.setTotal_vendido(res.getFloat("total_vendido"));
                obj.setPromedio_por_orden(res.getFloat("promedio_por_orden"));
                obj.setUltima_venta(res.getDate("ultima_venta"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return obj;
    }
}
