package org.example.restaurante.vistas;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import org.example.restaurante.componentes.BotonTeclado;

import java.util.ArrayList;

public class Teclado extends Stage {

    private static Teclado instancia;
    private static TextField campoActivo = new TextField();

    private Scene scene;
    private HBox renglones;
    private GridPane teclas, tecNumerico;
    private VBox root;

    private ArrayList<BotonTeclado> botonesLetras = new ArrayList<>();
    private boolean mayusculasActivadas = false;

    public static void asociarCampo(TextField campo) {
        campoActivo = campo;
        if (instancia == null) {
            instancia = new Teclado();
        } else {
            instancia.show();
        }
    }

    Teclado() {
        crearUI();
        this.setScene(scene);
        scene.getStylesheets().add(getClass().getResource("/styles/tecladoStyle.css").toString());
        this.setTitle("Teclado Virtual");
        this.show();
    }

    private void crearUI() {
        root = new VBox();
        renglones = new HBox();
        teclas = new GridPane();
        tecNumerico = new GridPane();

        root.setSpacing(20);
        renglones.setSpacing(50);
        root.setAlignment(Pos.CENTER);

        // Letras (a - ñ)
        char simbolo = 'a';
        for (int j = 0; j < 9; j++) {
            for (int i = 0; i < 3; i++) {
                if (simbolo > 'z') break;

                String val = String.valueOf(simbolo);
                if (simbolo == 'o') val = "ñ";
                if (simbolo >= 'p' && simbolo <= 'z') val = String.valueOf((char) (simbolo - 1));

                BotonTeclado btn = new BotonTeclado(val);
                btn.setOnAction(e -> campoActivo.appendText(btn.getText()));
                teclas.add(btn, j, i);

                botonesLetras.add(btn);
                simbolo++;
            }
        }

        // Números y signos: 1-9, ".", "0", ","
        simbolo = '1';
        int count = 0;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 3; j++) {
                if (count >= 12) break;

                String val;
                if (simbolo == ':') val = ".";
                else if (simbolo == ';') val = "0";
                else if (simbolo == '<') val = ",";
                else val = String.valueOf(simbolo);

                BotonTeclado btn = new BotonTeclado(val);
                btn.setOnAction(e -> campoActivo.appendText(btn.getText()));
                tecNumerico.add(btn, j, i);

                simbolo++;
                count++;
            }
        }

        // Borrar
        BotonTeclado borrar = new BotonTeclado("⌫");
        borrar.setOnAction(e -> {
            String text = campoActivo.getText();
            if (!text.isEmpty()) {
                campoActivo.setText(text.substring(0, text.length() - 1));
            }
        });

        // Espacio
        BotonTeclado espacio = new BotonTeclado("Espacio");
        espacio.setOnAction(e -> campoActivo.appendText(" "));

        // Shift
        BotonTeclado shift = new BotonTeclado("⇧");
        shift.setOnAction(e -> {
            mayusculasActivadas = !mayusculasActivadas;
            actualizarTeclas();
        });

        // Cerrar
        Button cerrar = new Button("Aceptar");
        cerrar.setOnAction(e -> this.hide());
        cerrar.getStyleClass().add("btnGuardar");

        HBox especiales = new HBox(10, borrar, espacio, shift, cerrar);
        especiales.setAlignment(Pos.CENTER);

        renglones.getChildren().addAll(teclas, tecNumerico);
        root.getChildren().addAll(renglones, especiales);
        scene = new Scene(root);
    }

    private void actualizarTeclas() {
        for (BotonTeclado btn : botonesLetras) {
            String txt = btn.getText();
            if (txt.equals("ñ")) continue; // ñ no cambia
            btn.setText(mayusculasActivadas ? txt.toUpperCase() : txt.toLowerCase());
        }
    }
}
