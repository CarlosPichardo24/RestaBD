package org.example.restaurante.componentes;

import javafx.collections.ObservableList;
import javafx.scene.layout.VBox;
import org.example.restaurante.modelosEntidad.CategoriaDAO;
import org.example.restaurante.vistas.Capturar;

public class MenuCat extends VBox {
    private int m;
    private FilaMenu inicio;
    private FilaMenu fin;
    private Capturar cap;
    private CategoriaDAO catSelec = null;

    public String textLine(String str){
        if (str == null) return "";
        return str.replace(" ", "\n");
    }

    public MenuCat(Capturar cap) {
        this.cap = cap;
        m = 6;
        fin = inicio = null;
        CategoriaDAO dao = new CategoriaDAO();
        crearMenu(dao.SELECT());
    }

    public void addItem(BtnMenu btn){
        if(inicio == null){
            fin = inicio = new FilaMenu(m);
            this.getChildren().add(inicio);
        }
        if(!fin.addBtn(btn)){
            FilaMenu temp = new FilaMenu(m);
            fin.sig = temp;
            fin = temp;
            this.getChildren().add(fin);
            fin.addBtn(btn);
        }
    }

    public void crearMenu(ObservableList<CategoriaDAO> categorias){
        for (CategoriaDAO cat : categorias) {
            BtnMenu<CategoriaDAO> btn = new BtnMenu("btnTouch", cat);
            btn.setText(textLine(cat.getNombre()));
            btn.setOnAction(e -> {
                catSelec = btn.getObj();
                cap.actProd();
            });
            addItem(btn);
        }
    }

    public CategoriaDAO getCatSelec() {
        return catSelec;
    }

}

