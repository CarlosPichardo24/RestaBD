package org.example.restaurante.componentes;

import javafx.scene.control.TextField;

public class TxtRegistro extends TextField {

    private String prompt;
    private String styleClass;

    public TxtRegistro(String prompt, String styleClass) {
        this.setPromptText(prompt);
        this.getStyleClass().add(styleClass);
    }
}
