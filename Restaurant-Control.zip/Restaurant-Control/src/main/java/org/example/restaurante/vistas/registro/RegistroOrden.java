package org.example.restaurante.vistas.registro;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.example.restaurante.componentes.MenuTouch;
import org.example.restaurante.modelosEntidad.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class RegistroOrden extends Stage{
    private Text title;
    private ComboBox<EmpleadoDAO> cmbEmpleado;
    private ComboBox<MesaDAO> cmbMesa;
    private ComboBox<ClienteDAO> cmbCliente;
    private EmpleadoDAO objEmpleado;
    private MesaDAO objMesa;
    private ClienteDAO objCliente;
    private Button btnGuardar, btnEmpleado, btnMesa, btnCliente;
    private HBox hMenu;
    private VBox vbox;
    private Scene scene;
    private OrdenDAO objOrden;
    private CuentaDAO objCuenta;

    public <T> ComboBox<T> cmbRegistro(String text){
        ComboBox<T> cmb = new ComboBox<>();
        cmb.getStyleClass().add("cmbRegistro");
        cmb.setPromptText(text);
        return cmb;
    }

    public Button btnMenu(String text, String url) {
        ImageView imv = new ImageView(getClass().getResource(url).toString());
        imv.setFitHeight(35);
        imv.setFitWidth(35);

        Button btn = new Button(text, imv);
        btn.getStyleClass().add("btnMenu");

        return btn;
    }

    public void crearMenu(){
        btnEmpleado = btnMenu("Empleado", "/iconos/iconoEmpleado.png");
        btnEmpleado.setOnAction(e ->{
            MenuTouch<EmpleadoDAO> menu = new MenuTouch<>(objEmpleado.SELECT(), "Empleado");
            menu.showAndWait();
            cmbEmpleado.setValue(menu.getObjSeleccionado());
        });
        btnMesa = btnMenu("Mesa", "/iconos/iconoMesa.png");
        btnMesa.setOnAction(e -> {
            MenuTouch<MesaDAO> menu = new MenuTouch<>(objMesa.SELECT(), "Mesa");
            menu.showAndWait();

            cmbMesa.setValue(menu.getObjSeleccionado());
        });
        btnCliente = btnMenu("Cliente", "/iconos/iconoCliente.png");
        btnCliente.setOnAction(e ->{
            MenuTouch<ClienteDAO> menu = new MenuTouch<>(objCliente.SELECT(), "Cliente");
            menu.showAndWait();

            cmbCliente.setValue(menu.getObjSeleccionado());
        });

        hMenu = new HBox(btnEmpleado, btnMesa, btnCliente);
        hMenu.setAlignment(Pos.CENTER);
    }

    public void crearCuenta(){
        objCuenta = new CuentaDAO();

        objCuenta.setIdOrden(objOrden.getIdOrden());
        objCuenta.INSERT();
    }

    public void crearUI(){
        title = new Text("Cuenta");
        title.getStyleClass().add("title");

        objEmpleado = new EmpleadoDAO();
        objMesa = new MesaDAO();
        objCliente = new ClienteDAO();

        cmbEmpleado = cmbRegistro("Empleado");
        cmbEmpleado.setItems(objEmpleado.SELECT());
        cmbMesa = cmbRegistro("Mesa");
        cmbMesa.setItems(objMesa.SELECT());
        cmbCliente = cmbRegistro("Cliente");
        cmbCliente.setItems(objCliente.SELECT());

        crearMenu();

        btnGuardar = new Button("Guardar");
        btnGuardar.getStyleClass().add("btnGuardar");
        btnGuardar.setOnAction(e -> {
            if(cmbEmpleado.getValue() != null)
                objOrden.setIdEmpleado(cmbEmpleado.getValue().getIdEmpleado());
            if(cmbMesa.getValue() != null)
                objOrden.setIdMesa(cmbMesa.getValue().getIdMesa());
            if(cmbCliente.getValue() != null)
                objOrden.setIdCliente(cmbCliente.getValue().getIdCliente());

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String fechaActual = LocalDateTime.now().format(formatter);
            objOrden.setFecha(fechaActual);

            if (objOrden.getIdOrden() > 0)
                objOrden.UPDATE();
            else{
                objOrden.INSERT();
                crearCuenta();
            }

            this.close();
        });


        vbox = new VBox(title, hMenu, cmbEmpleado, cmbMesa, cmbCliente, btnGuardar);
        vbox.getStyleClass().add("vboxBody");
        vbox.setPadding(new Insets(10, 10, 20, 10));
        vbox.setSpacing(10);
        vbox.setAlignment(Pos.TOP_CENTER);

        scene = new Scene(vbox);
        scene.getStylesheets().add(getClass().getResource("/styles/registroCuenta.css").toString());
    }

    public void llenar(OrdenDAO obj){
        objOrden = obj;

        cmbEmpleado.setValue(obj.getEmpleado());
        cmbMesa.setValue(obj.getMesa());
        cmbCliente.setValue(obj.getCliente());
    }

    public RegistroOrden(OrdenDAO objOrden) {
        if(objOrden == null){
            this.objOrden = new OrdenDAO();
            objCuenta  = new CuentaDAO();
        }
        else
            llenar(objOrden);
        crearUI();

        this.setMinWidth(320);
        this.setTitle("Cuenta");
        this.setScene(scene);
        this.show();
    }
}