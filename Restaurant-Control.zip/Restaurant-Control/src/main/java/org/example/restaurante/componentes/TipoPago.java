package org.example.restaurante.componentes;

public class TipoPago {
    private final String nombre;
    private final String rutaImagen;

    public TipoPago(String nombre, String rutaImagen) {
        this.nombre = nombre;
        this.rutaImagen = rutaImagen;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRutaImagen() {
        return rutaImagen;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
