package org.example.restaurante.componentes;

import javafx.scene.control.Button;

public class BotonTeclado extends Button {
    
    public BotonTeclado(String caracter)
    {
        this.setText(caracter);
        this.setPrefHeight(20);
        this.setPrefWidth(25);
        this.getStyleClass().add("botonTeclado");

        this.setOnAction(actionEvent -> {

        });
    }

}
