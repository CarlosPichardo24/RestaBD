package org.example.restaurante.modelosEntidad;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.restaurante.modelos.Conexion;

import java.sql.ResultSet;
import java.sql.Statement;

public class DetalleProductoDAO {
    private int idInsumo;
    private int idProducto;
    private int cantidad;

    public void INSERT(){
        String query = "INSERT INTO detalleProducto (idInsumo, idProducto, cantidad) " +
                "VALUES ("+idInsumo+","+idProducto+","+cantidad+")";
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void UPDATE(){
        String query = "UPDATE detalleProducto SET " +
                "idInsumo = "+idInsumo+", " +
                "idProducto = "+idProducto+", " +
                "cantidad = "+cantidad+" " +
                "WHERE idInsumo = "+idInsumo+" AND idProducto = "+idProducto;

        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void DELETE(){
        String query = "DELETE FROM detalleProducto WHERE idInsumo = "+idInsumo+" AND idProducto = "+idProducto;
        try{
            Statement stmt = Conexion.connection.createStatement();
            stmt.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ObservableList<DetalleProductoDAO> SELECT(){
        String query = "SELECT * FROM detalleProducto";
        ObservableList<DetalleProductoDAO> list = FXCollections.observableArrayList();
        DetalleProductoDAO obj;
        try{
            Statement stmt = Conexion.connection.createStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                obj = new DetalleProductoDAO();

                obj.setIdInsumo(res.getInt("idInsumo"));
                obj.setIdProducto(res.getInt("idProducto"));
                obj.setCantidad(res.getInt("cantidad"));

                list.add(obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public int getIdInsumo() {
        return idInsumo;
    }

    public void setIdInsumo(int idInsumo) {
        this.idInsumo = idInsumo;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
